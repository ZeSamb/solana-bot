import * as fs from 'fs';
import * as path from 'path';

type EventEntry = {
  type: string;
  timestamp: string;
  payload: Record<string, any>;
};

type AttemptRecord = {
  attemptId: string;
  tokenAddress?: string;
  tokenSymbol?: string;
  status?: string;
  reason?: string;
  buyAmount?: number;
  received?: number;
  buyPrice?: number;
  stopLossPrice?: number;
  takeProfitPrice?: number;
  liquidity?: number | null;
  initialBuy?: number | null;
  solAmount?: number | null;
  marketCap?: number | null;
  price?: number | null;
  activeTrades?: number;
  solBalance?: number;
  quoteOutAmount?: number | null;
  quotePriceImpactPct?: number | null;
  routePlanLegs?: number | null;
  signature?: string | null;
  pumpTimestamp?: string;
  attemptTimestamp?: string;
  resultTimestamp?: string;
  creator?: string | null;
  txType?: string | null;
};

const DATA_DIR = path.join(process.cwd(), 'data');
const SOURCE_FILE = path.join(DATA_DIR, 'events.jsonl');
const OUTPUT_FILE = path.join(DATA_DIR, 'dataset.csv');

function readEvents(): EventEntry[] {
  if (!fs.existsSync(SOURCE_FILE)) {
    console.error(`[exportDataset] No event log found at ${SOURCE_FILE}. Run the bot to generate data first.`);
    return [];
  }

  const lines = fs.readFileSync(SOURCE_FILE, { encoding: 'utf-8' }).split(/\r?\n/);
  const events: EventEntry[] = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    try {
      events.push(JSON.parse(trimmed));
    } catch (error) {
      console.warn('[exportDataset] Failed to parse line:', trimmed.slice(0, 120));
    }
  }
  return events;
}

function toNumber(value: any): number | null {
  if (value === null || value === undefined) return null;
  const num = Number(value);
  return Number.isFinite(num) ? num : null;
}

function toCsv(value: any): string {
  if (value === null || value === undefined) return '';
  const str = String(value);
  if (/[",\n]/.test(str)) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

function buildDataset(events: EventEntry[]): AttemptRecord[] {
  const pumpMetaByToken = new Map<string, { event: EventEntry; payload: Record<string, any> }>();
  const attempts = new Map<string, AttemptRecord>();
  const finalized: AttemptRecord[] = [];

  for (const event of events) {
    const payload = event.payload || {};

    switch (event.type) {
      case 'pump_event': {
        const tokenAddress = String(payload.tokenAddress || '');
        if (!tokenAddress) break;
        pumpMetaByToken.set(tokenAddress, { event, payload });
        break;
      }
      case 'trade_attempt': {
        const attemptId = String(payload.attemptId || '');
        if (!attemptId) break;
        const record: AttemptRecord = {
          attemptId,
          attemptTimestamp: event.timestamp,
          tokenAddress: payload.tokenAddress,
          tokenSymbol: payload.tokenSymbol,
          buyAmount: toNumber(payload.buyAmount) ?? undefined,
          liquidity: toNumber(payload.liquidity),
          initialBuy: toNumber(payload.initialBuy),
          solAmount: toNumber(payload.solAmount),
          activeTrades: toNumber(payload.activeTrades) ?? undefined,
          solBalance: toNumber(payload.solBalance) ?? undefined,
        };

        const pumpMeta = payload.tokenAddress ? pumpMetaByToken.get(payload.tokenAddress) : undefined;
        if (pumpMeta) {
          record.pumpTimestamp = pumpMeta.event.timestamp;
          record.marketCap = toNumber(pumpMeta.payload.marketCap);
          record.price = toNumber(pumpMeta.payload.price);
          record.creator = pumpMeta.payload.creator ?? null;
          record.txType = pumpMeta.payload.txType ?? null;
        }

        attempts.set(attemptId, record);
        break;
      }
      case 'quote_ready': {
        const attemptId = String(payload.attemptId || '');
        const record = attempts.get(attemptId);
        if (!record) break;
        record.quoteOutAmount = toNumber(payload.outAmount);
        record.quotePriceImpactPct = toNumber(payload.priceImpactPct);
        record.routePlanLegs = toNumber(payload.routePlanLegs);
        break;
      }
      case 'trade_result': {
        const attemptId = String(payload.attemptId || '');
        if (!attemptId) break;
        const record = attempts.get(attemptId) || {
          attemptId,
          attemptTimestamp: undefined,
        };

        record.resultTimestamp = event.timestamp;
        record.status = String(payload.status || 'unknown');
        record.reason = payload.error || payload.reason || undefined;
        if (payload.buyAmount !== undefined) record.buyAmount = toNumber(payload.buyAmount) ?? record.buyAmount;
        if (payload.received !== undefined) record.received = toNumber(payload.received) ?? record.received;
        if (payload.buyPrice !== undefined) record.buyPrice = toNumber(payload.buyPrice) ?? record.buyPrice;
        if (payload.stopLossPrice !== undefined) record.stopLossPrice = toNumber(payload.stopLossPrice) ?? record.stopLossPrice;
        if (payload.takeProfitPrice !== undefined) record.takeProfitPrice = toNumber(payload.takeProfitPrice) ?? record.takeProfitPrice;
        record.signature = payload.signature ?? record.signature ?? null;

        attempts.set(attemptId, record);
        finalized.push({ ...record });
        break;
      }
      default:
        break;
    }
  }

  return finalized;
}

function writeCsv(rows: AttemptRecord[]): void {
  if (!rows.length) {
    console.warn('[exportDataset] No trade attempts recorded yet. Nothing to export.');
    return;
  }

  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  const headers = [
    'attemptId',
    'tokenAddress',
    'tokenSymbol',
    'status',
    'reason',
    'buyAmount',
    'received',
    'buyPrice',
    'stopLossPrice',
    'takeProfitPrice',
    'liquidity',
    'initialBuy',
    'solAmount',
    'marketCap',
    'price',
    'activeTrades',
    'solBalance',
    'quoteOutAmount',
    'quotePriceImpactPct',
    'routePlanLegs',
    'signature',
    'pumpTimestamp',
    'attemptTimestamp',
    'resultTimestamp',
    'creator',
    'txType',
  ];

  const lines = [headers.join(',')];
  for (const row of rows) {
    const line = headers
      .map((header) => toCsv((row as Record<string, any>)[header] ?? ''))
      .join(',');
    lines.push(line);
  }

  fs.writeFileSync(OUTPUT_FILE, lines.join('\n'), { encoding: 'utf-8' });
  console.log(`[exportDataset] Wrote ${rows.length} rows to ${OUTPUT_FILE}`);
}

function main(): void {
  const events = readEvents();
  if (!events.length) return;
  const dataset = buildDataset(events);
  writeCsv(dataset);
}

main();
