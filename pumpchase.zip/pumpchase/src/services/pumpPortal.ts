// src/services/pumpPortal.ts
import WebSocket from 'ws';
import { Logger } from '../utils/logger';
import { TokenLaunch } from '../types';

type AnyMsg = {
  method?: string;
  // common fields seen in PumpPortal frames
  mint?: string;
  tokenAddress?: string;
  mintAddress?: string;
  symbol?: string;
  name?: string;
  liquidity?: number | string;
  market_cap?: number | string;
  marketCap?: number | string;
  price?: number | string;
  timestamp?: number | string;
  createdAt?: number | string;
  solAmount?: number | string;     // <-- often present on 'create'
  initialBuy?: number | string;    // <-- sometimes present too
  data?: any; // sometimes events are nested
};

export class PumpPortalService {
  private ws: WebSocket | null = null;
  private logger: Logger;
  private reconnectAttempts = 0;
  private readonly maxReconnectDelay = 30_000; // 30s
  private isConnected = false;
  private tokenLaunchCallback?: (tokenLaunch: TokenLaunch) => void;
  private wsUrl: string;
  private wsUrls: string[];
  private currentWsIndex = 0;
  private eventLoggingEnabled = true;

  // 🚫 De-dupe: remember symbols recently seen
  private recentBySymbol = new Map<string, number>();
  private readonly dedupeWindowMs = Number(process.env.PUMP_DEDUPE_WINDOW_MS || '120000'); // 2 min

  // ✅ Safe filter threshold (in SOL)
  private readonly minLiquiditySol = Number(process.env.MIN_LIQUIDITY_SOL || '0.05');

  constructor(wsUrl?: string) {
    this.logger = Logger.getInstance();

    // Build URL from env or constructor arg, default to official PumpPortal feed
    const envUrl =
      process.env.PUMP_PORTAL_WS_URL ||
      process.env.PUMPPORTAL_WS_URL ||
      process.env.PUMP_FUN_WS_URL ||
      process.env.PUMPPORTAL_WEBSOCKET;

    let base = (wsUrl || envUrl || 'wss://pumpportal.fun/api/data').trim();

    // Optional API key support: ?api-key=...
    const apiKey = process.env.PUMPPORTAL_API_KEY;
    if (apiKey && !base.includes('api-key=')) {
      base += (base.includes('?') ? '&' : '?') + `api-key=${encodeURIComponent(apiKey)}`;
    }

    const envListRaw =
      process.env.PUMPPORTAL_WS_URLS ||
      process.env.PUMP_PORTAL_WS_URLS ||
      '';

    const envList = envListRaw
      .split(',')
      .map((entry) => entry.trim())
      .filter(Boolean);

    const urls = [base, ...envList];
    const deduped = Array.from(new Set(urls.filter(Boolean)));

    if (deduped.length === 0) {
      deduped.push('wss://pumpportal.fun/api/data');
    }

    this.wsUrls = deduped.length > 0 ? deduped : ['wss://pumpportal.fun/api/data'];
    this.currentWsIndex = 0;
    const primary = this.wsUrls[0] ?? 'wss://pumpportal.fun/api/data';
    this.wsUrl = primary;
  }

  public async connect(): Promise<void> {
    const length = this.wsUrls.length || 1;
    for (let offset = 0; offset < length; offset++) {
      const index = (this.currentWsIndex + offset) % length;
      const endpoint = this.wsUrls[index] ?? this.wsUrls[0] ?? 'wss://pumpportal.fun/api/data';
      try {
        await this.establishConnection(endpoint);
        this.currentWsIndex = index;
        this.wsUrl = this.wsUrls[this.currentWsIndex] ?? endpoint;
        return;
      } catch (error: any) {
        this.logger.warn('PumpPortal connect attempt failed:', {
          endpoint,
          message: error?.message || String(error),
        });
      }
    }

    throw new Error(`Failed to connect to PumpPortal WebSocket after trying ${this.wsUrls.length || 1} endpoint(s)`);
  }

  private establishConnection(targetUrl: string): Promise<void> {
    return new Promise((resolve, reject) => {
      this.logger.info(`Connecting to PumpPortal WebSocket: ${targetUrl}`);

      try {
        const ws = new WebSocket(targetUrl);
        this.ws = ws;

        let settled = false;
        const timeout = setTimeout(() => {
          if (!settled) {
            settled = true;
            try { ws.terminate(); } catch {}
            reject(new Error('WebSocket connection timeout'));
          }
        }, 10_000);

        const handlePreOpenError = (error: Error) => {
          if (settled) return;
          settled = true;
          clearTimeout(timeout);
          try { ws.terminate(); } catch {}
          reject(new Error(`Failed to connect to PumpPortal WebSocket (${targetUrl}): ${error.message}`));
        };

        const onMessage = (data: WebSocket.Data) => {
          const raw = data.toString();
          if (this.eventLoggingEnabled) {
            this.logger.debug('PumpPortal raw:', raw.slice(0, 300));
          }
          const lines = raw.split('\n').filter(Boolean);
          for (const line of lines) {
            this.safeHandleLine(line);
          }
        };

        const onClose = (code: number, reason: Buffer) => {
          this.isConnected = false;
          this.logger.warn(`PumpPortal WebSocket closed: ${code} - ${reason?.toString?.() || ''}`);
          this.scheduleReconnect();
        };

        const onError = (error: Error) => {
          this.logger.error('PumpPortal WebSocket error:', error.message);
          try { ws.close(); } catch {}
        };

        ws.once('error', handlePreOpenError);

        ws.once('open', () => {
          if (settled) {
            return;
          }

          settled = true;
          clearTimeout(timeout);
          ws.off('error', handlePreOpenError);

          this.isConnected = true;
          this.reconnectAttempts = 0;
          this.wsUrl = targetUrl;
          this.logger.info('Connected to PumpPortal WebSocket');

          try {
            ws.send(JSON.stringify({ method: 'subscribeNewToken' }));
            this.logger.info('PumpPortal: subscribed to subscribeNewToken');
          } catch (e) {
            this.logger.error('PumpPortal subscribe error:', e);
          }

          ws.on('message', onMessage);
          ws.on('close', onClose);
          ws.on('error', onError);

          resolve();
        });
      } catch (error) {
        reject(new Error(`Failed to initialize WebSocket (${targetUrl}): ${error instanceof Error ? error.message : 'Unknown error'}`));
      }
    });
  }

  private scheduleReconnect() {
    this.reconnectAttempts += 1;
    const delay = Math.min(1000 * 2 ** Math.min(this.reconnectAttempts, 5), this.maxReconnectDelay);
    this.advanceWsUrl();
    this.logger.info(`PumpPortal: reconnecting in ${delay}ms (attempt ${this.reconnectAttempts}) using ${this.wsUrl}`);
    setTimeout(() => {
      this.connect().catch(err => this.logger.error('Reconnection failed:', err.message));
    }, delay);
  }

  private advanceWsUrl() {
    if (this.wsUrls.length <= 1) {
      return;
    }
    this.currentWsIndex = (this.currentWsIndex + 1) % this.wsUrls.length;
    this.wsUrl = this.wsUrls[this.currentWsIndex] ?? this.wsUrl;
  }

  private safeHandleLine(line: string) {
    try {
      // Some frames are a single object; some are wrapped with fields like {method, ...}
      const msg = JSON.parse(line) as AnyMsg;

      // If payload nested under msg.data, prefer that for fields
      const base = (msg && typeof msg.data === 'object') ? { ...msg, ...msg.data } : msg;

      // Normalize fields
      const mint =
        base.mint ||
        base.tokenAddress ||
        base.mintAddress ||
        (base as any).address;

      const rawSymbol = (base.symbol || base.name || (base as any).tokenSymbol || '').toString();
      const symbol = rawSymbol.trim();
      const symbolUpper = symbol.toUpperCase();

      // If we clearly got a new-token style event, forward it
      const looksLikeNewToken =
        (base.method === 'newToken' || base.method === 'subscribeNewToken') ||
        !!mint;

      if (looksLikeNewToken && mint) {
        // ✅ Use solAmount / initialBuy when liquidity is missing
        const liquidityRaw =
          base.liquidity ??
          (base as any).solAmount ??
          (base as any).initialBuy ??
          (base as any).data?.liquidity ??
          0;

        const liquidityNum = Number(liquidityRaw) || 0;
        const initialBuyRaw =
          (base as any).initialBuy ??
          (base as any).data?.initialBuy ??
          0;
        const solAmountRaw =
          (base as any).solAmount ??
          (base as any).data?.solAmount ??
          liquidityRaw ??
          0;

        // --- SAFE FILTERS -------------------------------------------------
        // 1) Symbol sanity
        if (!symbolUpper || symbolUpper.length < 2) {
          this.logger.debug('Skipped token — empty/short symbol', { mint });
          return;
        }

        // 2) Liquidity threshold (tunable with MIN_LIQUIDITY_SOL)
        if (liquidityNum < this.minLiquiditySol) {
          this.logger.debug(`Skipped ${symbolUpper} — liquidity ${liquidityNum} < ${this.minLiquiditySol}`);
          return;
        }

        // 3) De-dupe: avoid repeated buys on same symbol within a window
        const now = Date.now();
        const lastSeen = this.recentBySymbol.get(symbolUpper);
        if (lastSeen && (now - lastSeen) < this.dedupeWindowMs) {
          this.logger.debug(`Skipped duplicate symbol ${symbolUpper} (seen ${(now - lastSeen)}ms ago)`);
          return;
        }
        this.recentBySymbol.set(symbolUpper, now);
        // (Optional tiny GC)
        for (const [sym, t] of this.recentBySymbol) {
          if (now - t > this.dedupeWindowMs * 2) this.recentBySymbol.delete(sym);
        }
        // ------------------------------------------------------------------

        const marketCapRaw = base.marketCap ?? base.market_cap ?? (base as any).data?.market_cap;
        const priceRaw = base.price ?? (base as any).data?.price;

        const tokenLaunch: TokenLaunch = {
          tokenAddress: String(mint),
          tokenSymbol: String(symbolUpper),
          launchTime: Number(base.timestamp || base.createdAt || Date.now()),
          liquidity: liquidityNum, // post-filter, non-trivial
          marketCap: marketCapRaw != null ? Number(marketCapRaw) : undefined,
          price: priceRaw != null ? Number(priceRaw) : undefined,
          initialBuy: Number(initialBuyRaw) || undefined,
          solAmount: Number(solAmountRaw) || undefined,
          txSignature: (base as any).signature || (base as any).txSignature,
          creator: (base as any).traderPublicKey || (base as any).creator,
          bondingCurveKey: (base as any).bondingCurveKey || (base as any).bondingCurvePubkey,
          txType: (base as any).txType || (base as any).method,
        };

        if (this.eventLoggingEnabled) {
          this.logger.trade('New token launch detected:', {
            symbol: tokenLaunch.tokenSymbol,
            address: tokenLaunch.tokenAddress,
            liquidity: tokenLaunch.liquidity,
            marketCap: tokenLaunch.marketCap,
          });
        }

        if (this.tokenLaunchCallback) {
          this.tokenLaunchCallback(tokenLaunch);
        }
        return;
      }

      // Unknown / other message types (keep at debug)
      this.logger.debug('PumpPortal unrecognized frame:', { method: (base as any).method, sample: line.slice(0, 120) });
    } catch (err) {
      this.logger.error('PumpPortal parse error:', err);
    }
  }

  public onTokenLaunch(callback: (tokenLaunch: TokenLaunch) => void): void {
    this.tokenLaunchCallback = callback;
  }

  public disconnect(): void {
    if (this.ws) {
      try { this.ws.close(); } catch {}
      this.ws = null;
      this.isConnected = false;
      this.logger.info('Disconnected from PumpPortal WebSocket');
    }
  }

  public getConnectionStatus(): boolean {
    return this.isConnected;
  }

  public setEventLogging(enabled: boolean): void {
    this.eventLoggingEnabled = enabled;
  }
}
