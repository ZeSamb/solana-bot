import TelegramBot from 'node-telegram-bot-api';
import { Logger } from '../utils/logger';
import { Trade, TokenLaunch, SwapResult } from '../types';

export class TelegramService {
  private bot: TelegramBot | null = null;
  private chatId: string | null = null;
  private logger: Logger;
  private isEnabled = false;

  constructor(botToken?: string, chatId?: string) {
    this.logger = Logger.getInstance();

    if (botToken && chatId) {
      this.bot = new TelegramBot(botToken, { polling: false });
      this.chatId = chatId;
      this.isEnabled = true;
      this.logger.info('Telegram notifications enabled');
    } else {
      this.logger.info('Telegram notifications disabled - missing token or chat ID');
    }
  }

  public async sendMessage(message: string): Promise<boolean> {
    if (!this.isEnabled || !this.bot || !this.chatId) {
      return false;
    }

    try {
      await this.bot.sendMessage(this.chatId, message, {
        parse_mode: 'HTML',
        disable_web_page_preview: true
      });
      return true;
    } catch (error) {
      this.logger.error('Error sending Telegram message:', error);
      return false;
    }
  }

  public async notifyTokenLaunch(tokenLaunch: TokenLaunch): Promise<void> {
    const message = `🚀 <b>New Token Launch Detected!</b>

` +
      `<b>Symbol:</b> ${tokenLaunch.tokenSymbol}
` +
      `<b>Address:</b> <code>${tokenLaunch.tokenAddress}</code>
` +
      `<b>Liquidity:</b> ${tokenLaunch.liquidity.toFixed(2)} SOL
` +
      (tokenLaunch.marketCap ? `<b>Market Cap:</b> ${tokenLaunch.marketCap.toFixed(2)} SOL
` : '') +
      (tokenLaunch.price ? `<b>Price:</b> ${tokenLaunch.price.toFixed(8)} SOL
` : '') +
      `<b>Time:</b> ${new Date(tokenLaunch.launchTime).toLocaleString()}`;

    await this.sendMessage(message);
  }

  public async notifyBuy(trade: Trade, swapResult: SwapResult): Promise<void> {
    const message = `🟢 <b>BUY EXECUTED</b>

` +
      `<b>Token:</b> ${trade.tokenSymbol}
` +
      `<b>Address:</b> <code>${trade.tokenAddress}</code>
` +
      `<b>Amount:</b> ${trade.buyAmount.toFixed(4)} SOL
` +
      `<b>Price:</b> ${trade.buyPrice.toFixed(8)} SOL
` +
      `<b>Stop Loss:</b> ${trade.stopLossPrice.toFixed(8)} SOL
` +
      `<b>Take Profit:</b> ${trade.takeProfitPrice.toFixed(8)} SOL
` +
      `<b>Tx:</b> <code>${swapResult.signature || 'N/A'}</code>`;

    await this.sendMessage(message);
  }

  public async notifySell(trade: Trade, swapResult: SwapResult): Promise<void> {
    const pnlEmoji = trade.pnl && trade.pnl > 0 ? '💰' : '📉';
    const pnlText = trade.pnl && trade.pnlPercentage
      ? `${trade.pnl > 0 ? '+' : ''}${trade.pnl.toFixed(4)} SOL (${trade.pnlPercentage > 0 ? '+' : ''}${trade.pnlPercentage.toFixed(2)}%)`
      : 'N/A';

    const message = `${pnlEmoji} <b>SELL EXECUTED</b>

` +
      `<b>Token:</b> ${trade.tokenSymbol}
` +
      `<b>Address:</b> <code>${trade.tokenAddress}</code>
` +
      `<b>Buy Price:</b> ${trade.buyPrice.toFixed(8)} SOL
` +
      `<b>Sell Price:</b> ${trade.sellPrice?.toFixed(8)} SOL
` +
      `<b>PnL:</b> ${pnlText}
` +
      `<b>Tx:</b> <code>${swapResult.signature || 'N/A'}</code>`;

    await this.sendMessage(message);
  }

  public async notifyStopLoss(trade: Trade, swapResult: SwapResult): Promise<void> {
    const message = `🔴 <b>STOP LOSS TRIGGERED</b>

` +
      `<b>Token:</b> ${trade.tokenSymbol}
` +
      `<b>Address:</b> <code>${trade.tokenAddress}</code>
` +
      `<b>Buy Price:</b> ${trade.buyPrice.toFixed(8)} SOL
` +
      `<b>Sell Price:</b> ${trade.sellPrice?.toFixed(8)} SOL
` +
      `<b>Loss:</b> ${trade.pnlPercentage?.toFixed(2)}%
` +
      `<b>Tx:</b> <code>${swapResult.signature || 'N/A'}</code>`;

    await this.sendMessage(message);
  }

  public async notifyTakeProfit(trade: Trade, swapResult: SwapResult): Promise<void> {
    const message = `🎯 <b>TAKE PROFIT HIT</b>

` +
      `<b>Token:</b> ${trade.tokenSymbol}
` +
      `<b>Address:</b> <code>${trade.tokenAddress}</code>
` +
      `<b>Buy Price:</b> ${trade.buyPrice.toFixed(8)} SOL
` +
      `<b>Sell Price:</b> ${trade.sellPrice?.toFixed(8)} SOL
` +
      `<b>Profit:</b> +${trade.pnlPercentage?.toFixed(2)}%
` +
      `<b>Tx:</b> <code>${swapResult.signature || 'N/A'}</code>`;

    await this.sendMessage(message);
  }

  public async notifyError(error: string, context?: string): Promise<void> {
    const message = `❌ <b>ERROR</b>

` +
      (context ? `<b>Context:</b> ${context}
` : '') +
      `<b>Error:</b> ${error}`;

    await this.sendMessage(message);
  }

  public async notifyBotStatus(status: {
    isRunning: boolean;
    activeTrades: number;
    totalTrades: number;
    totalPnL: number;
    totalPnLPercentage: number;
    uptime: number;
  }): Promise<void> {
    const statusEmoji = status.isRunning ? '🟢' : '🔴';
    const uptimeHours = Math.floor(status.uptime / (1000 * 60 * 60));
    const uptimeMinutes = Math.floor((status.uptime % (1000 * 60 * 60)) / (1000 * 60));

    const message = `${statusEmoji} <b>BOT STATUS</b>

` +
      `<b>Status:</b> ${status.isRunning ? 'RUNNING' : 'STOPPED'}
` +
      `<b>Active Trades:</b> ${status.activeTrades}
` +
      `<b>Total Trades:</b> ${status.totalTrades}
` +
      `<b>Total PnL:</b> ${status.totalPnL.toFixed(4)} SOL (${status.totalPnLPercentage > 0 ? '+' : ''}${status.totalPnLPercentage.toFixed(2)}%)
` +
      `<b>Uptime:</b> ${uptimeHours}h ${uptimeMinutes}m`;

    await this.sendMessage(message);
  }

  public isTelegramEnabled(): boolean {
    return this.isEnabled;
  }
}