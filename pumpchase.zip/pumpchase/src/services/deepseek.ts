import fetch from 'node-fetch';
import { Logger } from '../utils/logger';
import { AIFilterDecision, AIFilterFeatures, AIRiskLevel } from '../types';

export interface DeepseekConfig {
  apiKey?: string;
  model: string;
  enabled: boolean;
  minScore: number; // 0-100
  maxRiskLevel: AIRiskLevel;
  retries: number;
  timeoutMs: number;
  confidenceThreshold: number; // 0-1
  logScope?: string;
}

const RISK_ORDER: Record<AIRiskLevel, number> = {
  low: 0,
  medium: 1,
  high: 2,
};

type GuardConfig = {
  minScore: number;
  maxRiskLevel: AIRiskLevel;
  confidenceThreshold: number;
};

function sanitizeJson(text: string): string | null {
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  return jsonMatch ? jsonMatch[0] : null;
}

export class DeepseekService {
  private readonly logger: Logger;
  private readonly cfg: DeepseekConfig;

  constructor(config: DeepseekConfig) {
    this.cfg = config;
    this.logger = Logger.getInstance();
  }

  public isEnabled(): boolean {
    return Boolean(this.cfg.enabled && this.cfg.apiKey);
  }

  public async evaluate(
    features: AIFilterFeatures,
    overrides?: Partial<GuardConfig>,
  ): Promise<AIFilterDecision | null> {
    if (!this.isEnabled()) {
      return null;
    }

    const guard: GuardConfig = {
      minScore: overrides?.minScore ?? this.cfg.minScore,
      maxRiskLevel: overrides?.maxRiskLevel ?? this.cfg.maxRiskLevel,
      confidenceThreshold: overrides?.confidenceThreshold ?? this.cfg.confidenceThreshold,
    };

    let lastError: unknown;
    for (let attempt = 0; attempt <= this.cfg.retries; attempt++) {
      try {
        const decision = await this.requestDecision(features, guard);
        if (decision) {
          return this.applyGuards(decision, guard);
        }
      } catch (error) {
        lastError = error;
        this.logger.warn('[Deepseek] evaluation attempt failed', {
          attempt: attempt + 1,
          retries: this.cfg.retries + 1,
          error: error instanceof Error ? error.message : String(error),
        });
        if (attempt < this.cfg.retries) {
          await new Promise((resolve) => setTimeout(resolve, 250 * (attempt + 1)));
        }
      }
    }

    if (lastError) {
      this.logger.error('[Deepseek] all attempts failed', lastError);
    }
    return null;
  }

  private applyGuards(decision: AIFilterDecision, guard: GuardConfig): AIFilterDecision {
    const scoreOk = decision.score >= guard.minScore;
    const riskOk = RISK_ORDER[decision.risk] <= RISK_ORDER[guard.maxRiskLevel];
    const confidenceOk = decision.confidence >= guard.confidenceThreshold;
    const approved = scoreOk && riskOk && confidenceOk && decision.approved;

    if (!approved) {
      const reasons = [
        !decision.approved ? 'model_disapproved' : null,
        !scoreOk ? 'score_below_threshold' : null,
        !riskOk ? 'risk_above_max' : null,
        !confidenceOk ? 'confidence_below_threshold' : null,
      ].filter(Boolean);

      return {
        ...decision,
        approved: false,
        rationale: `${decision.rationale} | filters=${reasons.join(',')} | thresholds=minScore:${guard.minScore},maxRisk:${guard.maxRiskLevel},minConfidence:${guard.confidenceThreshold}`.trim(),
      };
    }

    return { ...decision, approved: true };
  }

  private buildPrompt(features: AIFilterFeatures, guard: GuardConfig): { system: string; user: string } {
    const system = [
      'You are an elite crypto quant helping a Solana memecoin sniper bot decide which fresh launches to trade.',
      'Always respond with concise JSON using keys approved (boolean), score (0-100), risk (low|medium|high), confidence (0-1), rationale (<=200 chars).',
      'The bot focuses on ultra-short holding periods (< 10 minutes) and wants asymmetric upside with controlled drawdowns.',
      'Requests may represent fresh launches ("launch") or later momentum entries ("momentum"); check payload.context for details.',
    ].join(' ');

    const payload: Record<string, unknown> = {
      token: {
        symbol: features.tokenSymbol,
        address: features.tokenAddress,
        liquiditySol: features.liquidity,
        marketCap: features.marketCap ?? null,
        priceSol: features.price ?? features.currentPrice ?? null,
        initialPriceSol: features.initialPrice ?? null,
        currentPriceSol: features.currentPrice ?? null,
        initialBuySol: features.initialBuy ?? null,
        solAmount: features.solAmount ?? null,
        creator: features.creator ?? null,
        ageSeconds: features.ageSeconds ?? null,
      },
      portfolio: {
        activeTrades: features.activeTrades,
        maxConcurrentTrades: features.maxConcurrentTrades,
      },
      riskSettings: {
        stopLossPct: features.stopLossPercentage,
        takeProfitPct: features.takeProfitPercentage,
      },
      context: {
        evaluation: features.evaluationContext ?? 'launch',
        ageSeconds: features.ageSeconds ?? null,
        priceChangePct: features.priceChangePct ?? null,
        stepChangePct: features.stepChangePct ?? null,
        liquidityChangePct: features.liquidityChangePct ?? null,
        aiRejectedAtLaunch: features.aiRejectedAtLaunch ?? false,
        watchlistAttempts: features.watchlistAttempts ?? null,
        sampleWindowSeconds: features.sampleWindowSeconds ?? null,
      },
      filters: {
        minScore: guard.minScore,
        maxRiskLevel: guard.maxRiskLevel,
        minConfidence: guard.confidenceThreshold,
      },
    };

    if ((features.evaluationContext ?? 'launch') === 'momentum') {
      payload.momentum = {
        initialLiquiditySol: features.initialLiquidity ?? null,
        currentLiquiditySol: features.currentLiquidity ?? null,
        liquidityChangePct: features.liquidityChangePct ?? null,
        priceChangePct: features.priceChangePct ?? null,
        stepChangePct: features.stepChangePct ?? null,
      };
    }

    const user = `Evaluate token using JSON only. Data: ${JSON.stringify(payload)}`;
    return { system, user };
  }

  private async requestDecision(features: AIFilterFeatures, guard: GuardConfig): Promise<AIFilterDecision | null> {
    const prompts = this.buildPrompt(features, guard);
    const body = {
      model: this.cfg.model,
      temperature: 0.2,
      max_tokens: 400,
      messages: [
        { role: 'system', content: prompts.system },
        { role: 'user', content: prompts.user },
      ],
    };

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.cfg.timeoutMs);

    try {
      const response = await fetch('https://api.deepseek.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${this.cfg.apiKey}`,
        },
        body: JSON.stringify(body),
        signal: controller.signal,
      } as any);

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const payload = await response.json();
      const content: string = payload?.choices?.[0]?.message?.content ?? '';
      if (!content) {
        throw new Error('Empty Deepseek response');
      }

      const raw = sanitizeJson(content) ?? content;
      try {
        const parsed = JSON.parse(raw);
        const decision: AIFilterDecision = {
          approved: Boolean(parsed.approved),
          score: Number(parsed.score ?? 0),
          risk: this.normalizeRisk(parsed.risk),
          confidence: Number(parsed.confidence ?? parsed.confidenceScore ?? 0),
          rationale: String(parsed.rationale ?? parsed.reason ?? parsed.summary ?? ''),
          rawResponse: typeof parsed.rawResponse === 'string' ? parsed.rawResponse : content,
        };
        decision.score = Number.isFinite(decision.score) ? Math.max(0, Math.min(100, decision.score)) : 0;
        decision.confidence = Number.isFinite(decision.confidence) ? Math.max(0, Math.min(1, decision.confidence)) : 0;
        return decision;
      } catch (parseError) {
        this.logger.warn('[Deepseek] failed to parse JSON response', {
          error: parseError instanceof Error ? parseError.message : String(parseError),
          content,
        });
        return null;
      }
    } finally {
      clearTimeout(timeout);
    }
  }

  private normalizeRisk(value: unknown): AIRiskLevel {
    const str = String(value || '').toLowerCase();
    if (str === 'low' || str === 'medium' || str === 'high') {
      return str;
    }
    if (str.includes('high')) {
      return 'high';
    }
    if (str.includes('medium')) {
      return 'medium';
    }
    if (str.includes('low')) {
      return 'low';
    }
    return this.cfg.maxRiskLevel;
  }
}

