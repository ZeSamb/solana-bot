// src/services/jupiter.ts
import fetch from 'node-fetch';
import {
  Connection,
  Keypair,
  PublicKey,
  VersionedTransaction,
} from '@solana/web3.js';
import { Logger } from '../utils/logger';
import { Config, JupiterQuote, JupiterSwapResponse, SwapResult } from '../types';

type QuoteOrError = JupiterQuote | { error?: string; message?: string };

export class JupiterService {
  private connection: Connection;
  private wallet: Keypair;
  private cfg: Config;
  private logger: Logger;
  private baseUrls: string[];
  private currentBaseUrlIndex = 0;
  private mintDecimalsCache = new Map<string, number>();
  private rateLimitUntil = new Map<string, number>();

  constructor(connection: Connection, wallet: Keypair, cfg: Config) {
    this.connection = connection;
    this.wallet = wallet;
    this.cfg = cfg;
    this.logger = Logger.getInstance(cfg.logLevel);

    const explicitSingle = process.env.JUPITER_API_URL?.trim();
    const multiEnv = process.env.JUPITER_API_URLS || '';
    const multiList = multiEnv
      .split(',')
      .map((entry) => entry.trim())
      .filter(Boolean);

    const urls = [explicitSingle, ...multiList].filter((value): value is string => Boolean(value));
    const deduped = Array.from(new Set(urls));

    if (deduped.length === 0) {
      deduped.push('https://quote-api.jup.ag');
    }

    this.baseUrls = deduped;
  }

  private getOrderedBaseUrls(): string[] {
    if (this.baseUrls.length === 0) {
      return ['https://quote-api.jup.ag'];
    }

    const now = Date.now();
    const ready: string[] = [];
    const deferred: string[] = [];
    for (let offset = 0; offset < this.baseUrls.length; offset++) {
      const index = (this.currentBaseUrlIndex + offset) % this.baseUrls.length;
      const entry = this.baseUrls[index];
      if (entry) {
        const limitUntil = this.rateLimitUntil.get(entry) ?? 0;
        if (limitUntil > now) {
          deferred.push(entry);
        } else {
          ready.push(entry);
        }
      }
    }
    const ordered = [...ready, ...deferred];
    return ordered.length > 0 ? ordered : ['https://quote-api.jup.ag'];
  }

  private isNativeSol(mint: string): boolean {
    return mint === 'So11111111111111111111111111111111111111112';
  }

  public async getBalance(mint: string): Promise<number> {
    if (this.isNativeSol(mint)) {
      const lamports = await this.connection.getBalance(this.wallet.publicKey);
      return lamports / 1e9;
    }

    try {
      const parsed = await this.connection.getParsedTokenAccountsByOwner(this.wallet.publicKey, { mint: new PublicKey(mint) });
      const total = parsed.value.reduce((sum, account) => {
        const info: any = account.account.data;
        const amount = info?.parsed?.info?.tokenAmount?.uiAmount ?? 0;
        return sum + Number(amount);
      }, 0);
      return total;
    } catch (error) {
      this.logger.error('Jupiter balance fetch error:', { mint, error: (error as Error).message });
      return 0;
    }
  }

  private async getMintDecimals(mint: string): Promise<number> {
    if (this.isNativeSol(mint)) {
      return 9;
    }

    const cached = this.mintDecimalsCache.get(mint);
    if (typeof cached === 'number') {
      return cached;
    }

    try {
      const accountInfo = await this.connection.getParsedAccountInfo(new PublicKey(mint));
      const parsed: any = accountInfo.value?.data;
      const decimals = parsed?.parsed?.info?.decimals;
      if (typeof decimals === 'number') {
        this.mintDecimalsCache.set(mint, decimals);
        return decimals;
      }
    } catch (error) {
      this.logger.error('Mint decimals fetch error:', { mint, error: (error as Error).message });
    }

    this.mintDecimalsCache.set(mint, 9);
    return 9;
  }

  private async toRawAmount(mint: string, uiAmount: number): Promise<bigint> {
    if (!Number.isFinite(uiAmount) || uiAmount <= 0) {
      return 0n;
    }
    const decimals = await this.getMintDecimals(mint);
    const factor = Math.pow(10, decimals);
    const raw = BigInt(Math.round(uiAmount * factor));
    return raw;
  }

  public async toUiAmount(mint: string, raw: string | number | bigint): Promise<number> {
    const rawBig = typeof raw === 'bigint' ? raw : BigInt(raw);
    const decimals = await this.getMintDecimals(mint);
    const factor = Math.pow(10, decimals);
    return Number(rawBig) / factor;
  }

  private markRateLimited(baseUrl: string, retryAfterMs?: number): void {
    const backoff = retryAfterMs ?? 2000;
    const nextAllowed = Date.now() + Math.max(500, backoff);
    this.rateLimitUntil.set(baseUrl, nextAllowed);
  }

  public async getQuoteOnce(
    inMint: string,
    outMint: string,
    uiAmountIn: number,
  ): Promise<JupiterQuote | null> {
    const rawAmount = await this.toRawAmount(inMint, uiAmountIn);
    if (rawAmount <= 0n) {
      this.logger.warn('Jupiter: requested quote for zero amount', { inMint, uiAmountIn });
      return null;
    }

    const orderedBaseUrls = this.getOrderedBaseUrls();
    for (let offset = 0; offset < orderedBaseUrls.length; offset++) {
      const baseUrl = orderedBaseUrls[offset];
      if (!baseUrl) {
        continue;
      }
      const url =
        `${baseUrl}/v6/quote?` +
        `inputMint=${encodeURIComponent(inMint)}` +
        `&outputMint=${encodeURIComponent(outMint)}` +
        `&amount=${rawAmount.toString()}` +
        `&slippageBps=${this.cfg.slippageBps || 500}` +
        `&onlyDirectRoutes=false` +
        `&asLegacyTransaction=false`;

      try {
        const nowTs = Date.now();
        const limitUntil = this.rateLimitUntil.get(baseUrl) ?? 0;
        if (limitUntil > nowTs) {
          this.logger.debug('Jupiter base temporarily rate-limited, skipping', {
            baseUrl,
            retryMs: Math.max(0, limitUntil - nowTs),
          });
          continue;
        }

        const response = await fetch(url, { timeout: 10_000 } as any);
        const text = await response.text();

        let data: QuoteOrError | undefined;
        try {
          data = JSON.parse(text) as QuoteOrError;
        } catch {
          data = undefined;
        }

        if (!response.ok) {
          const msg = (data as any)?.error || (data as any)?.message || `HTTP ${response.status}`;
          if (response.status === 400 || response.status === 404) {
            this.logger.debug('Jupiter: no route yet', { outMint, msg });
            return null;
          }
          if (response.status === 429) {
            const retryAfterHeader = response.headers.get('retry-after');
            const retryAfterSeconds = retryAfterHeader ? parseFloat(retryAfterHeader) : NaN;
            const retryMs = Number.isFinite(retryAfterSeconds) ? retryAfterSeconds * 1000 : undefined;
            this.markRateLimited(baseUrl, retryMs);
          }
          this.logger.warn('Jupiter quote HTTP error', { url, status: response.status, msg });
          continue;
        }

        if (!data || 'error' in data || 'message' in data) {
          this.logger.debug('Jupiter quote says no route', data);
          return null;
        }

        this.currentBaseUrlIndex = (this.currentBaseUrlIndex + offset) % this.baseUrls.length;
        return data as JupiterQuote;
      } catch (error: any) {
        this.logger.warn('Jupiter quote network/parse error', {
          baseUrl,
          message: error?.message || String(error),
          code: error?.code || error?.errno,
        });
      }
    }

    this.logger.error('Jupiter: all configured endpoints failed', { endpoints: this.baseUrls });
    return null;
  }

  public async waitForRoute(
    inMint: string,
    outMint: string,
    uiAmountIn: number,
    maxWaitMs = Number(process.env.ROUTE_WAIT_MS || 30_000),
    pollMs = Number(process.env.ROUTE_POLL_MS || 2_000),
  ): Promise<JupiterQuote | null> {
    const deadline = Date.now() + maxWaitMs;
    let attempt = 0;

    while (Date.now() < deadline) {
      attempt += 1;
      const quote = await this.getQuoteOnce(inMint, outMint, uiAmountIn);
      if (quote) {
        this.logger.info('Jupiter route ready', { attempts: attempt, outAmount: quote.outAmount });
        return quote;
      }
      await new Promise((resolve) => setTimeout(resolve, pollMs));
    }

    this.logger.warn('Jupiter: gave up waiting for route', { outMint, waitedMs: maxWaitMs });
    return null;
  }

  public async doSwap(quote: JupiterQuote, options?: { skipPreflight?: boolean }): Promise<SwapResult> {
    const orderedBaseUrls = this.getOrderedBaseUrls();

    for (let offset = 0; offset < orderedBaseUrls.length; offset++) {
      const baseUrl = orderedBaseUrls[offset];
      const payload: Record<string, any> = {
        quoteResponse: quote,
        userPublicKey: this.wallet.publicKey.toBase58(),
        wrapAndUnwrapSol: true,
        asLegacyTransaction: false,
      };

      if (this.cfg.computeUnitLimit && this.cfg.computeUnitLimit > 0) {
        payload.computeUnitLimit = this.cfg.computeUnitLimit;
      }
      if (this.cfg.computeUnitPrice && this.cfg.computeUnitPrice > 0) {
        payload.computeUnitPriceMicroLamports = Math.round(this.cfg.computeUnitPrice * 1_000_000);
      }
      if (this.cfg.customFee && this.cfg.customFee > 0) {
        payload.prioritizationFeeLamports = Math.round(this.cfg.customFee);
      }
      if (this.cfg.useSharedAccounts) {
        payload.useSharedAccounts = true;
      }

      try {
        const response = await fetch(`${baseUrl}/v6/swap`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
          timeout: 15_000,
        } as any);

        const text = await response.text();
        let data: any;
        try {
          data = JSON.parse(text);
        } catch {
          data = undefined;
        }

        if (!response.ok || !data || !data.swapTransaction) {
          const msg = data?.error || data?.message || `HTTP ${response.status}`;
          this.logger.warn('Jupiter swap HTTP error', { baseUrl, status: response.status, msg });
          continue;
        }

        const swapResponse = data as JupiterSwapResponse;
        const transactionBuf = Buffer.from(swapResponse.swapTransaction, 'base64');
        const transaction = VersionedTransaction.deserialize(transactionBuf);
        transaction.sign([this.wallet]);

        let signature: string;
        try {
          signature = await this.connection.sendTransaction(transaction, {
            skipPreflight: options?.skipPreflight ?? false,
            maxRetries: this.cfg.maxRetries ?? undefined,
            preflightCommitment: this.cfg.commitmentLevel,
          });
        } catch (sendError: any) {
          this.logger.error('Jupiter swap send error', {
            baseUrl,
            message: sendError?.message || String(sendError),
          });
          continue;
        }

        try {
          await this.connection.confirmTransaction(
            {
              signature,
              blockhash: transaction.message.recentBlockhash,
              lastValidBlockHeight: swapResponse.lastValidBlockHeight,
            },
            this.cfg.commitmentLevel,
          );
        } catch (confirmError: any) {
          this.logger.error('Jupiter swap confirmation error', {
            signature,
            message: confirmError?.message || String(confirmError),
          });
          return { success: false, error: `Confirmation failed: ${confirmError?.message || confirmError}`, signature };
        }

        const inputAmount = await this.toUiAmount(quote.inputMint, quote.inAmount);
        const outputAmount = await this.toUiAmount(quote.outputMint, quote.outAmount);
        this.currentBaseUrlIndex = (this.currentBaseUrlIndex + offset) % this.baseUrls.length;
        return { success: true, outputAmount, inputAmount, signature };
      } catch (error: any) {
        this.logger.warn('Jupiter swap error', {
          baseUrl,
          message: error?.message || String(error),
        });
      }
    }

    return { success: false, error: 'All Jupiter endpoints failed for swap' };
  }

  public async swap(inMint: string, outMint: string, uiAmountIn: number): Promise<SwapResult> {
    const quote = await this.waitForRoute(inMint, outMint, uiAmountIn);
    if (!quote) {
      return { success: false, error: 'No route available yet', inputAmount: uiAmountIn, outputAmount: 0 };
    }
    return this.doSwap(quote);
  }
}
