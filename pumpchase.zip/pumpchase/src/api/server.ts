// src/api/server.ts
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import type { TradingBot } from '../trading/bot';

export class APIServer {
  private app = express();
  private server: any;
  private readonly bot: TradingBot;
  private readonly port: number;

  constructor(bot: TradingBot, port?: number) {
    this.bot = bot;
    this.port = Number(process.env.PORT || port || 3000);

    this.app.use(cors());
    this.app.use(bodyParser.json());

    // health
    this.app.get('/health', (_req, res) => res.json({ ok: true }));

    // status
    this.app.get('/status', (_req, res) => {
      const s = this.bot.getStatus?.() || {
        isRunning: this.bot.isBotRunning?.() ?? false,
        activeTrades: 0,
        totalTrades: 0,
        totalPnL: 0,
        totalPnLPercentage: 0,
        uptime: 0,
      };
      res.json(s);
    });

    // start
    this.app.post('/start', async (_req, res) => {
      try {
        if (this.bot.isBotRunning?.()) {
          return res.json({ ok: true, message: 'already running' });
        }
        await this.bot.start();
        return res.json({ ok: true, message: 'started' });
      } catch (e: any) {
        return res.status(500).json({
          error: 'Failed to start trading bot',
          details: e?.message || String(e),
        });
      }
    });

    // stop
    this.app.post('/stop', async (_req, res) => {
      try {
        if (!this.bot.isBotRunning?.()) {
          return res.json({ ok: true, message: 'already stopped' });
        }
        await this.bot.stop();
        return res.json({ ok: true, message: 'stopped' });
      } catch (e: any) {
        return res.status(500).json({
          error: 'Failed to stop trading bot',
          details: e?.message || String(e),
        });
      }
    });

    // logs (basic stub)
    this.app.get('/logs', (_req, res) => {
      // If you have a file transport, stream last N lines here.
      res.json({
        message: 'Logs endpoint stub. Wire your logger file transport if needed.',
      });
    });
  }

  public start() {
    if (this.server) return;
    this.server = this.app.listen(this.port, '0.0.0.0', () => {
      // eslint-disable-next-line no-console
      console.log(`API server running on port ${this.port}`);
      console.log('Available endpoints:');
      console.log(`  http://localhost:${this.port}/health`);
      console.log(`  http://localhost:${this.port}/start`);
      console.log(`  http://localhost:${this.port}/stop`);
      console.log(`  http://localhost:${this.port}/status`);
      console.log(`  http://localhost:${this.port}/logs`);
    });

    this.server.on('error', (err: any) => {
      // eslint-disable-next-line no-console
      console.error('API server error:', err);
      process.exit(1);
    });
  }

  public async stop() {
    if (this.server) {
      await new Promise<void>((resolve) => this.server.close(() => resolve()));
      this.server = null;
    }
  }
}
