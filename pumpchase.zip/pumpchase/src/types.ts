import { PublicKey, Transaction } from '@solana/web3.js';

export type AIRiskLevel = 'low' | 'medium' | 'high';

export interface AIFilterDecision {
  approved: boolean;
  score: number;
  risk: AIRiskLevel;
  confidence: number;
  rationale: string;
  rawResponse?: string;
}

export interface AIFilterFeatures {
  tokenAddress: string;
  tokenSymbol: string;
  liquidity: number;
  marketCap?: number;
  price?: number;
  initialPrice?: number;
  currentPrice?: number;
  priceChangePct?: number;
  stepChangePct?: number;
  initialLiquidity?: number;
  currentLiquidity?: number;
  liquidityChangePct?: number;
  initialBuy?: number;
  solAmount?: number;
  creator?: string;
  ageSeconds?: number;
  evaluationContext?: 'launch' | 'momentum';
  aiRejectedAtLaunch?: boolean;
  watchlistAttempts?: number;
  sampleWindowSeconds?: number;
  activeTrades: number;
  maxConcurrentTrades: number;
  stopLossPercentage: number;
  takeProfitPercentage: number;
}



export interface Config {
  // Wallet
  privateKey: string;
  rpcEndpoint: string;
  rpcWebsocketEndpoint: string;
  commitmentLevel: 'processed' | 'confirmed' | 'finalized';

  // Logs
  logLevel: string;

  // Core Behavior
  oneTokenAtATime: boolean;
  preLoadExistingMarkets: boolean;
  cacheNewMarkets: boolean;
  transactionExecutor: string;

  // Trading
  buyAmountSol: number;
  quoteMint: string;
  baseMint: string;
  quoteAmount: number;
  baseAmount: number;
  autoBuyDelay: number;
  maxConcurrentTrades: number;
  slippageBps: number;

  // Risk Management
  stopLossPercentage: number;
  takeProfitPercentage: number;
  autoSell: boolean;
  sellDelay: number;
  maxRetries: number;
  retryDelay: number;
  partialTakeProfitEnabled: boolean;
  partialTakeProfitFraction: number;
  takeProfitFinalPercentage: number;
  breakEvenStopLossAfterPartial: boolean;
  priceProbeAmount: number;
  priceProbeTokenAmount: number;

  // Heuristics
  minLiquiditySol: number;
  minInitialBuySol: number;
  minSolAmount: number;
  symbolDenyList: string[];
  symbolAllowList: string[];
  creatorDenyList: string[];
  creatorAllowList: string[];
  creatorCooldownMs: number;
  creatorWindowMs: number;
  maxCreatorTradesPerWindow: number;
  globalTradeCooldownMs: number;
  minFreeSolBalance: number;

  // Performance
  computeUnitLimit: number;
  computeUnitPrice: number;
  customFee: number;
  preSwapChecks: boolean;
  useSharedAccounts: boolean;

  // Execution
  tradeLive: boolean;

  // Telegram
  telegramBotToken?: string;
  telegramChatId?: string;

  // External APIs
  solanaVibeStationApiKey?: string;

  // AI Filtering
  deepseekApiKey?: string;
  deepseekModel?: string;
  aiFilteringEnabled: boolean;
  aiMinScore: number;
  aiMaxRiskLevel: AIRiskLevel;
  aiRetryAttempts: number;
  aiTimeoutMs: number;
  aiConfidenceThreshold: number;

  // Momentum re-entry
  momentumEnabled: boolean;
  momentumMinAgeSeconds: number;
  momentumMaxAgeSeconds: number;
  momentumReevalIntervalMs: number;
  momentumMinPriceChangePct: number;
  momentumMinStepChangePct: number;
  momentumMinScore: number;
  momentumMaxWatchlistSize: number;
  momentumMaxEvaluations: number;

  // PumpPortal
  pumpPortalWsUrl?: string;

  // API
  apiPort: number;
  autoStart: boolean;

  // Jupiter routing (wait + retries)
  routeWaitMs: number;
  routePollMs: number;
  routeRetryAttempts: number;
  routeRetryDelayMs: number;
  routeRetryWaitMs: number;
}

export interface Trade {
  id: string;
  tokenAddress: string;
  tokenSymbol: string;
  buyPrice: number;
  buyAmount: number;
  buyTimestamp: number;
  tokenAmount: number;
  remainingTokenAmount: number;
  remainingCostBasis: number;
  realizedPnL: number;
  partialTakeProfitExecuted?: boolean;
  aiDecision?: AIFilterDecision;
  sellPrice?: number;
  sellAmount?: number;
  sellTimestamp?: number;
  entryReason?: string;
  momentumPriceChangePct?: number | null;
  momentumAgeSeconds?: number | null;
  status: 'open' | 'closed' | 'stopped';
  pnl?: number;
  pnlPercentage?: number;
  stopLossPrice: number;
  takeProfitPrice: number;
}

export interface TokenLaunch {
  tokenAddress: string;
  tokenSymbol: string;
  launchTime: number;
  liquidity: number;
  marketCap?: number;
  price?: number;
  initialBuy?: number;
  solAmount?: number;
  txSignature?: string;
  creator?: string;
  bondingCurveKey?: string;
  txType?: string;
}

export interface SwapResult {
  success: boolean;
  signature?: string;
  error?: string;
  inputAmount?: number;
  outputAmount?: number;
  priceImpact?: number;
}

export interface BotStatus {
  isRunning: boolean;
  activeTrades: number;
  totalTrades: number;
  totalPnL: number;
  totalPnLPercentage: number;
  uptime: number;
  lastTradeTime?: number;
}

export interface PumpPortalMessage {
  type: 'token_launch' | 'price_update' | 'liquidity_update';
  data: {
    token_address: string;
    token_symbol: string;
    timestamp: number;
    liquidity?: number;
    price?: number;
    market_cap?: number;
  };
}

export interface JupiterQuote {
  inputMint: string;
  outputMint: string;
  inAmount: string;
  outAmount: string;
  otherAmountThreshold: string;
  swapMode: string;
  slippageBps: number;
  platformFee?: {
    amount: string;
    feeBps: number;
  };
  priceImpactPct: string;
  routePlan: Array<{
    swapInfo: any;
    percent: number;
  }>;
  contextSlot?: number;
  timeTaken?: number;
}

export interface JupiterSwapResponse {
  swapTransaction: string;
  lastValidBlockHeight: number;
  prioritizationFeeLamports?: number;
}



