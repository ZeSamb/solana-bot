import 'dotenv/config';
import { Connection, Keypair } from '@solana/web3.js';
import bs58 from 'bs58';
import { Logger } from './utils/logger';
import { TradingBot } from './trading/bot';
import { APIServer } from './api/server';
import { Config, AIRiskLevel } from './types';

// Resolve PumpPortal WS URL from different env spellings
function resolvePumpPortalUrl(): string {
  const {
    PUMP_PORTAL_WS_URL,
    PUMPPORTAL_WS_URL,
    PUMP_FUN_WS_URL,
    PUMPPORTAL_WEBSOCKET,
    PUMPPORTAL_API_KEY,
  } = process.env;

  let base =
    PUMP_PORTAL_WS_URL ||
    PUMPPORTAL_WS_URL ||
    PUMP_FUN_WS_URL ||
    PUMPPORTAL_WEBSOCKET ||
    "wss://pumpportal.fun/api/data";

  if (PUMPPORTAL_API_KEY && !base.includes("api-key=")) {
    base += (base.includes("?") ? "&" : "?") + `api-key=${encodeURIComponent(PUMPPORTAL_API_KEY)}`;
  }
  return base;
}

class Application {
  private logger: Logger;
  private config: Config;
  private connection: Connection;
  private wallet: Keypair;
  private bot: TradingBot | null = null;
  private apiServer: APIServer | null = null;

  constructor() {
    this.logger = Logger.getInstance();
    this.config = this.loadConfig();
    this.connection = this.createConnection();
    this.wallet = this.loadWallet();
  }

  private loadConfig(): Config {
    const requiredEnvVars = [
      'PRIVATE_KEY',
      'RPC_ENDPOINT',
      'RPC_WEBSOCKET_ENDPOINT'
    ];

    const missingVars = requiredEnvVars.filter(varName => !process.env[varName]);
    if (missingVars.length > 0) {
      throw new Error(`Missing required environment variables: ${missingVars.join(', ')}`);
    }

    const routeWaitMs = parseInt(
      process.env.ROUTE_WAIT_MS ||
      process.env.JUPITER_ROUTE_TIMEOUT_MS ||
      '60000',
      10
    );

    const routePollMs = parseInt(
      process.env.ROUTE_POLL_MS ||
      process.env.JUPITER_ROUTE_POLL_MS ||
      '1000',
      10
    );

    const routeRetryAttempts = Math.max(
      0,
      parseInt(process.env.ROUTE_RETRY_ATTEMPTS || '2', 10)
    );

    const routeRetryDelayMs = Math.max(
      0,
      parseInt(process.env.ROUTE_RETRY_DELAY_MS || '4000', 10)
    );

    const routeRetryWaitMs = Math.max(
      1000,
      parseInt(
        process.env.ROUTE_RETRY_WAIT_MS ||
          (Math.max(routeWaitMs, 15000)).toString(),
        10
      )
    );

    const symbolDenyList = (process.env.SYMBOL_DENY_LIST || '')
      .split(',')
      .map(item => item.trim().toUpperCase())
      .filter(Boolean);

    const symbolAllowList = (process.env.SYMBOL_ALLOW_LIST || '')
      .split(',')
      .map(item => item.trim().toUpperCase())
      .filter(Boolean);

    const creatorDenyList = (process.env.CREATOR_DENY_LIST || '')
      .split(',')
      .map(item => item.trim())
      .filter(Boolean);

    const creatorAllowList = (process.env.CREATOR_ALLOW_LIST || '')
      .split(',')
      .map(item => item.trim())
      .filter(Boolean);

    const stopLossPercentage = parseFloat(process.env.STOP_LOSS_PERCENTAGE || '20');
    const takeProfitPercentage = parseFloat(process.env.TAKE_PROFIT_PERCENTAGE || '50');

    const partialTakeProfitEnabled = String(process.env.PARTIAL_TAKE_PROFIT_ENABLED ?? 'true').toLowerCase() === 'true';
    const partialTakeProfitFractionRaw = parseFloat(process.env.PARTIAL_TAKE_PROFIT_FRACTION || '0.5');
    const partialTakeProfitFraction = Number.isFinite(partialTakeProfitFractionRaw)
      ? Math.min(0.95, Math.max(0.05, partialTakeProfitFractionRaw))
      : 0.5;
    const takeProfitFinalPercentageRaw = parseFloat(process.env.TAKE_PROFIT_FINAL_PERCENTAGE || Math.max(takeProfitPercentage * 1.5, takeProfitPercentage + 20).toString());
    const takeProfitFinalPercentage = Number.isFinite(takeProfitFinalPercentageRaw)
      ? Math.max(takeProfitPercentage, takeProfitFinalPercentageRaw)
      : takeProfitPercentage * 1.5;
    const breakEvenStopLossAfterPartial = String(process.env.BREAK_EVEN_STOP_LOSS_AFTER_PARTIAL ?? 'true').toLowerCase() === 'true';

    const deepseekApiKey = process.env.DEEPSEEK_API_KEY;
    const deepseekModel = process.env.DEEPSEEK_MODEL || 'deepseek-chat';
    const aiFilterEnabledEnv = process.env.AI_FILTER_ENABLED ?? (deepseekApiKey ? 'true' : 'false');
    const aiFilteringEnabled = String(aiFilterEnabledEnv).toLowerCase() === 'true';
    const aiMinScore = Math.min(100, Math.max(0, parseFloat(process.env.AI_MIN_SCORE || '70')));
    const aiMaxRiskEnv = (process.env.AI_MAX_RISK_LEVEL || 'medium').toLowerCase();
    const aiMaxRiskLevel: AIRiskLevel = aiMaxRiskEnv === 'low' || aiMaxRiskEnv === 'medium' || aiMaxRiskEnv === 'high'
      ? aiMaxRiskEnv as AIRiskLevel
      : 'medium';
    const aiRetryAttempts = Math.max(0, parseInt(process.env.AI_RETRY_ATTEMPTS || '1', 10));
    const aiTimeoutMs = Math.max(1000, parseInt(process.env.AI_TIMEOUT_MS || '8000', 10));
    const aiConfidenceThreshold = Math.min(1, Math.max(0, parseFloat(process.env.AI_CONFIDENCE_THRESHOLD || '0.45')));
    
    const momentumEnabled = String(process.env.MOMENTUM_ENABLED ?? 'true').toLowerCase() === 'true';
    const momentumMinAgeSeconds = Math.max(0, parseInt(process.env.MOMENTUM_MIN_AGE_SECONDS || '60', 10));
    const momentumMaxAgeSeconds = Math.max(momentumMinAgeSeconds, parseInt(process.env.MOMENTUM_MAX_AGE_SECONDS || '600', 10));
    const momentumReevalIntervalMs = Math.max(5000, (parseInt(process.env.MOMENTUM_REEVAL_INTERVAL_SECONDS || '30', 10) || 30) * 1000);
    const momentumMinPriceChangePct = Math.max(0, parseFloat(process.env.MOMENTUM_MIN_PRICE_CHANGE_PCT || '25'));
    const momentumMinStepChangePct = Math.max(0, parseFloat(process.env.MOMENTUM_MIN_STEP_CHANGE_PCT || '5'));
    const momentumMinScoreRaw = parseFloat(
      process.env.MOMENTUM_MIN_AI_SCORE || Math.min(100, aiMinScore + 10).toString()
    );
    const momentumMinScore = Number.isFinite(momentumMinScoreRaw)
      ? Math.min(100, Math.max(aiMinScore, momentumMinScoreRaw))
      : Math.min(100, aiMinScore + 10);
    const momentumMaxWatchlistSize = Math.max(
      5,
      parseInt(process.env.MOMENTUM_MAX_WATCHLIST_SIZE || '60', 10)
    );
    const momentumMaxEvaluations = Math.max(
      1,
      parseInt(process.env.MOMENTUM_MAX_EVALUATIONS || '12', 10)
    );
    const priceProbeAmountRaw = parseFloat(process.env.PRICE_PROBE_AMOUNT || '0.001');
    const priceProbeAmount = Number.isFinite(priceProbeAmountRaw)
      ? Math.min(0.1, Math.max(0.0001, priceProbeAmountRaw))
      : 0.001;
    const priceProbeTokenAmountRaw = parseFloat(process.env.PRICE_PROBE_TOKEN_AMOUNT || '10');
    const priceProbeTokenAmount = Number.isFinite(priceProbeTokenAmountRaw)
      ? Math.max(0.000001, priceProbeTokenAmountRaw)
      : 10;

    return {
      // Wallet
      privateKey: process.env.PRIVATE_KEY!,
      rpcEndpoint: process.env.RPC_ENDPOINT!,
      rpcWebsocketEndpoint: process.env.RPC_WEBSOCKET_ENDPOINT!,
      commitmentLevel: (process.env.COMMITMENT_LEVEL as 'processed' | 'confirmed' | 'finalized') || 'confirmed',

      // Logs
      logLevel: process.env.LOG_LEVEL || 'info',

      // Core Behavior
      oneTokenAtATime: process.env.ONE_TOKEN_AT_A_TIME === 'true',
      preLoadExistingMarkets: process.env.PRE_LOAD_EXISTING_MARKETS === 'true',
      cacheNewMarkets: process.env.CACHE_NEW_MARKETS === 'true',
      transactionExecutor: process.env.TRANSACTION_EXECUTOR || 'default',

      // Trading
      buyAmountSol: parseFloat(process.env.BUY_AMOUNT_SOL || '0.01'),
      quoteMint: process.env.QUOTE_MINT || 'So11111111111111111111111111111111111111112',
      baseMint: process.env.BASE_MINT || '',
      quoteAmount: parseFloat(process.env.QUOTE_AMOUNT || '0'),
      baseAmount: parseFloat(process.env.BASE_AMOUNT || '0'),
      autoBuyDelay: parseInt(process.env.AUTO_BUY_DELAY || '2000'),
      maxConcurrentTrades: parseInt(process.env.MAX_CONCURRENT_TRADES || '5'),
      slippageBps: parseInt(process.env.SLIPPAGE_BPS || '500'),

      // Risk Management
      stopLossPercentage,
      takeProfitPercentage,
      autoSell: process.env.AUTO_SELL === 'true',
      sellDelay: parseInt(process.env.SELL_DELAY || '2000'),
      maxRetries: parseInt(process.env.MAX_RETRIES || '3'),
      retryDelay: parseInt(process.env.RETRY_DELAY || '1000'),
      partialTakeProfitEnabled,
      partialTakeProfitFraction,
      takeProfitFinalPercentage,
      breakEvenStopLossAfterPartial,
      priceProbeAmount,
      priceProbeTokenAmount,

      // Heuristics
      minLiquiditySol: parseFloat(process.env.MIN_LIQUIDITY_SOL || '0.05'),
      minInitialBuySol: parseFloat(process.env.MIN_INITIAL_BUY_SOL || '0.05'),
      minSolAmount: parseFloat(process.env.MIN_SOL_AMOUNT || '0.05'),
      symbolDenyList,
      symbolAllowList,
      creatorDenyList,
      creatorAllowList,
      creatorCooldownMs: parseInt(process.env.CREATOR_COOLDOWN_MS || '600000', 10),
      creatorWindowMs: parseInt(process.env.CREATOR_WINDOW_MS || '1800000', 10),
      maxCreatorTradesPerWindow: parseInt(process.env.MAX_CREATOR_TRADES_PER_WINDOW || '2', 10),
      globalTradeCooldownMs: parseInt(process.env.GLOBAL_TRADE_COOLDOWN_MS || '5000', 10),
      minFreeSolBalance: parseFloat(process.env.MIN_FREE_SOL_BALANCE || '0.01'),

      // Performance
      computeUnitLimit: parseInt(process.env.COMPUTE_UNIT_LIMIT || '800000'),
      computeUnitPrice: parseFloat(process.env.COMPUTE_UNIT_PRICE || '0'),
      customFee: parseFloat(process.env.CUSTOM_FEE || '0'),
      preSwapChecks: process.env.PRE_SWAP_CHECKS === 'true',
      useSharedAccounts: process.env.JUPITER_USE_SHARED_ACCOUNTS === 'true',

      // Execution
      tradeLive: String(process.env.TRADE_LIVE || 'true').toLowerCase() === 'true',

      // Telegram
      telegramBotToken: process.env.TELEGRAM_BOT_TOKEN,
      telegramChatId: process.env.TELEGRAM_CHAT_ID,

      // External APIs
      solanaVibeStationApiKey: process.env.SOLANA_VIBE_STATION_API_KEY,

      // AI Filtering
      deepseekApiKey,
      deepseekModel,
      aiFilteringEnabled,
      aiMinScore,
      aiMaxRiskLevel,
      aiRetryAttempts,
      aiTimeoutMs,
      aiConfidenceThreshold,

      // Momentum re-entry
      momentumEnabled,
      momentumMinAgeSeconds,
      momentumMaxAgeSeconds,
      momentumReevalIntervalMs,
      momentumMinPriceChangePct,
      momentumMinStepChangePct,
      momentumMinScore,
      momentumMaxWatchlistSize,
      momentumMaxEvaluations,

      // PumpPortal (FIXED)
      pumpPortalWsUrl: resolvePumpPortalUrl(),

      // API Port + Auto-start
      apiPort: parseInt(process.env.PORT || '3000', 10),
      autoStart: String(process.env.AUTO_START || '').toLowerCase() === 'true',

      // Jupiter routing behaviour
      routeWaitMs,
      routePollMs,
      routeRetryAttempts,
      routeRetryDelayMs,
      routeRetryWaitMs,
    };
  }

  private createConnection(): Connection {
    return new Connection(this.config.rpcEndpoint, {
      commitment: this.config.commitmentLevel,
      wsEndpoint: this.config.rpcWebsocketEndpoint
    });
  }

  private loadWallet(): Keypair {
    try {
      const privateKey = bs58.decode(this.config.privateKey);
      return Keypair.fromSecretKey(privateKey);
    } catch (error) {
      throw new Error('Failed to load wallet from private key. Please check your PRIVATE_KEY environment variable.');
    }
  }

  private async initialize(): Promise<void> {
    this.logger.info('Initializing Solana Trading Bot...');

    // Validate wallet
    const balance = await this.connection.getBalance(this.wallet.publicKey);
    const solBalance = balance / 1e9;

    this.logger.info('Wallet initialized:', {
      publicKey: this.wallet.publicKey.toString(),
      balance: `${solBalance.toFixed(4)} SOL`
    });

    if (solBalance < this.config.buyAmountSol) {
      this.logger.warn('Low SOL balance. Consider funding your wallet.');
    }

    // Initialize trading bot
    this.bot = new TradingBot(this.config, this.connection, this.wallet);

    // Log PumpPortal URL
    this.logger.info('PumpPortal WS URL:', this.config.pumpPortalWsUrl);

    // Initialize API server
    this.apiServer = new APIServer(this.bot, this.config.apiPort);

    this.logger.info('Application initialized successfully');
  }

  public async start(): Promise<void> {
    try {
      await this.initialize();

      // Start API server
      if (this.apiServer) {
        this.apiServer.start();
      }

      this.logger.info('🚀 Solana Trading Bot is ready!');
      this.logger.info('Use the API endpoints to control the bot:');
      this.logger.info('  POST /start - Start trading');
      this.logger.info('  POST /stop  - Stop trading');
      this.logger.info('  GET  /status - Check bot status');

      // Auto start trading
      if (this.config.autoStart && this.bot && !this.bot.isBotRunning()) {
        this.logger.info('AUTO_START is true — starting trading loop...');
        await this.bot.start().catch((e: any) => {
          this.logger.error('Auto-start failed:', e);
        });
      }

      this.setupGracefulShutdown();
    } catch (error) {
      this.logger.error('Failed to start application:', error);
      process.exit(1);
    }
  }

  private setupGracefulShutdown(): void {
    const shutdown = async (signal: string) => {
      this.logger.info(`Received ${signal}. Shutting down gracefully...`);

      try {
        if (this.bot && this.bot.isBotRunning()) {
          await this.bot.stop();
        }
        this.logger.info('Shutdown completed');
        process.exit(0);
      } catch (error) {
        this.logger.error('Error during shutdown:', error);
        process.exit(1);
      }
    };

    process.on('SIGINT', () => shutdown('SIGINT'));
    process.on('SIGTERM', () => shutdown('SIGTERM'));

    process.on('uncaughtException', (error) => {
      this.logger.error('Uncaught exception:', error);
      shutdown('UNCAUGHT_EXCEPTION');
    });

    process.on('unhandledRejection', (reason, promise) => {
      this.logger.error('Unhandled promise rejection:', { reason, promise });
      shutdown('UNHANDLED_REJECTION');
    });
  }
}

const app = new Application();
app.start().catch((error) => {
  console.error('Fatal error during startup:', error);
  process.exit(1);
});


