import * as fs from 'fs';
import { promises as fsp } from 'fs';
import * as path from 'path';

type DataEvent = {
  type: string;
  timestamp: string;
  payload: Record<string, unknown>;
};

/**
 * Simple JSONL event recorder so we can build offline datasets for backtesting and ML.
 */
export class DataRecorder {
  private static instance: DataRecorder;

  private readonly dataDir: string;
  private readonly eventLogPath: string;

  private writeQueue: string[] = [];
  private writing = false;

  private constructor() {
    const customDir = process.env.DATA_DIR ? process.env.DATA_DIR.trim() : '';
    this.dataDir = customDir ? path.resolve(customDir) : path.join(process.cwd(), 'data');
    this.eventLogPath = path.join(this.dataDir, 'events.jsonl');
    this.ensureDir();
  }

  public static getInstance(): DataRecorder {
    if (!DataRecorder.instance) {
      DataRecorder.instance = new DataRecorder();
    }
    return DataRecorder.instance;
  }

  private ensureDir(): void {
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }
    if (!fs.existsSync(this.eventLogPath)) {
      fs.writeFileSync(this.eventLogPath, '', { encoding: 'utf-8' });
    }
  }

  public log(type: string, payload: Record<string, unknown>): void {
    const entry: DataEvent = {
      type,
      timestamp: new Date().toISOString(),
      payload,
    };
    const line = JSON.stringify(entry) + '\n';
    this.writeQueue.push(line);
    void this.processQueue();
  }

  private async processQueue(retry = 0): Promise<void> {
    if (this.writing) {
      return;
    }
    const next = this.writeQueue.shift();
    if (!next) {
      return;
    }
    this.writing = true;
    try {
      await fsp.appendFile(this.eventLogPath, next, { encoding: 'utf-8' });
      this.writing = false;
      if (this.writeQueue.length > 0) {
        void this.processQueue();
      }
    } catch (error: any) {
      const code = error?.code;
      this.writing = false;
      if (code === 'EBUSY' || code === 'EPERM') {
        const delay = Math.min(500 * (retry + 1), 2000);
        setTimeout(() => {
          // Re-queue and retry.
          this.writeQueue.unshift(next);
          void this.processQueue(retry + 1);
        }, delay);
      } else {
        console.warn('[DataRecorder] Failed to persist event', { error });
        // drop the line to avoid blocking, but continue with remainder.
        if (this.writeQueue.length > 0) {
          void this.processQueue();
        }
      }
    }
  }
}
