export class Logger {
  private static instance: Logger;
  private logLevel: string;
  private silentMode = false;

  private constructor(logLevel: string = 'info') {
    this.logLevel = logLevel;
  }

  public static getInstance(logLevel?: string): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger(logLevel);
    }
    return Logger.instance;
  }

  private shouldLog(level: string): boolean {
    if (this.silentMode && (level === 'info' || level === 'debug')) {
      return false;
    }
    const levels = ['error', 'warn', 'info', 'debug'];
    const currentLevelIndex = levels.indexOf(this.logLevel);
    const messageLevelIndex = levels.indexOf(level);
    return messageLevelIndex <= currentLevelIndex;
  }

  private formatMessage(level: string, message: string, ...args: any[]): string {
    const timestamp = new Date().toISOString();
    const formattedArgs = args.map(arg =>
      typeof arg === 'object' ? JSON.stringify(arg, null, 2) : arg
    ).join(' ');

    return `[${timestamp}] [${level.toUpperCase()}] ${message} ${formattedArgs}`;
  }

  public error(message: string, ...args: any[]): void {
    if (this.shouldLog('error')) {
      console.error(this.formatMessage('error', message, ...args));
    }
  }

  public warn(message: string, ...args: any[]): void {
    if (this.shouldLog('warn')) {
      console.warn(this.formatMessage('warn', message, ...args));
    }
  }

  public info(message: string, ...args: any[]): void {
    if (this.shouldLog('info')) {
      console.log(this.formatMessage('info', message, ...args));
    }
  }

  public debug(message: string, ...args: any[]): void {
    if (this.shouldLog('debug')) {
      console.debug(this.formatMessage('debug', message, ...args));
    }
  }

  public trade(message: string, ...args: any[]): void {
    if (this.silentMode) {
      return;
    }
    const timestamp = new Date().toISOString();
    const formattedArgs = args.map(arg =>
      typeof arg === 'object' ? JSON.stringify(arg, null, 2) : arg
    ).join(' ');

    console.log(`\x1b[36m[${timestamp}] [TRADE] ${message} ${formattedArgs}\x1b[0m`);
  }

  public setLogLevel(level: string): void {
    this.logLevel = level;
  }

  public setSilentMode(enabled: boolean): void {
    this.silentMode = enabled;
  }
}
