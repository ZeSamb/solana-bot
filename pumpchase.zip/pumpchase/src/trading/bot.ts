import WebSocket from "ws";
import { Connection, Keypair } from '@solana/web3.js';
import { Logger } from '../utils/logger';
import { PumpPortalService } from '../services/pumpPortal';
import { JupiterService } from '../services/jupiter';
import { DeepseekService } from '../services/deepseek';
import { TelegramService } from '../services/telegram';
import { Config, Trade, TokenLaunch, BotStatus, SwapResult, JupiterQuote, AIFilterDecision, AIFilterFeatures, AIRiskLevel } from '../types';
import * as fs from 'fs';
import * as path from 'path';
import { DataRecorder } from '../utils/dataRecorder';

const SOL_MINT = 'So11111111111111111111111111111111111111112';

interface MomentumWatchEntry {
  token: TokenLaunch;
  addedAt: number;
  initialPrice?: number;
  lastPrice?: number;
  initialLiquidity?: number;
  lastLiquidity?: number;
  lastEvaluated: number;
  aiRejected: boolean;
  attempts: number;
  lastDecision?: AIFilterDecision | null;
}

type DeepseekGuardOverrides = Partial<{
  minScore: number;
  maxRiskLevel: AIRiskLevel;
  confidenceThreshold: number;
}>;
export class TradingBot {
  private config: Config;
  private connection: Connection;
  private wallet: Keypair;
  private logger: Logger;
  private pumpPortal: PumpPortalService;
  private jupiter: JupiterService;
  private telegram: TelegramService;
  private dataRecorder: DataRecorder;
  private deepseek?: DeepseekService;

  private isRunning = false;
  private activeTrades: Map<string, Trade> = new Map();
  private completedTrades: Trade[] = [];
  private startTime: number = 0;
  private tradesFile: string;
  private inFlightTrades: Set<string> = new Set();
  private capacityAlerted = false;
  private watchlist: Map<string, MomentumWatchEntry> = new Map();
  private momentumTimer: NodeJS.Timeout | null = null;
  private monitoringPaused = false;

  // === WS fallback fields ===
  private ws: WebSocket | null = null;
  private reconnectAttempts = 0;
  private lastPumpEventTs = 0;
  private watchdogTimer: NodeJS.Timeout | null = null;

  // Heuristics state
  private creatorTradeHistory: Map<string, number[]> = new Map();
  private lastGlobalTradeTimestamp = 0;

  constructor(config: Config, connection: Connection, wallet: Keypair) {
    this.config = config;
    this.connection = connection;
    this.wallet = wallet;
    this.logger = Logger.getInstance(config.logLevel);
    this.pumpPortal = new PumpPortalService(config.pumpPortalWsUrl);
    this.jupiter = new JupiterService(connection, wallet, config);
    this.telegram = new TelegramService(config.telegramBotToken, config.telegramChatId);
    this.dataRecorder = DataRecorder.getInstance();

    if (this.config.aiFilteringEnabled) {
      this.deepseek = new DeepseekService({
        apiKey: this.config.deepseekApiKey,
        model: this.config.deepseekModel || 'deepseek-chat',
        enabled: Boolean(this.config.aiFilteringEnabled && this.config.deepseekApiKey),
        minScore: this.config.aiMinScore,
        maxRiskLevel: this.config.aiMaxRiskLevel,
        retries: this.config.aiRetryAttempts,
        timeoutMs: this.config.aiTimeoutMs,
        confidenceThreshold: this.config.aiConfidenceThreshold,
      });

      if (this.deepseek?.isEnabled()) {
        this.logger.info('Deepseek AI filtering enabled', {
          minScore: this.config.aiMinScore,
          maxRisk: this.config.aiMaxRiskLevel,
          confidenceThreshold: this.config.aiConfidenceThreshold,
        });
      } else {
        this.logger.warn('AI filtering enabled but Deepseek API key missing or invalid. Disabling AI filter.');
        this.deepseek = undefined;
        this.config.aiFilteringEnabled = false;
      }
    }

    this.tradesFile = path.join(process.cwd(), 'trades.json');

    this.loadTrades();
    this.setupEventHandlers();

    if (this.config.momentumEnabled) {
      this.logger.info('Momentum re-entry enabled', {
        minAgeSeconds: this.config.momentumMinAgeSeconds,
        maxAgeSeconds: this.config.momentumMaxAgeSeconds,
        minPriceChangePct: this.config.momentumMinPriceChangePct,
        minStepChangePct: this.config.momentumMinStepChangePct,
        minScore: this.config.momentumMinScore,
        intervalMs: this.config.momentumReevalIntervalMs,
      });
    }
  }

  private setupEventHandlers(): void {
    // Primary path: rely on PumpPortalService
    this.pumpPortal.onTokenLaunch((tokenLaunch: TokenLaunch) => {
      this.lastPumpEventTs = Date.now();
      this.handleTokenLaunch(tokenLaunch);
    });
  }

  private getMomentumProbeAmount(): number {
    const base = this.config.buyAmountSol || 0.01;
    return Math.min(0.25, Math.max(0.005, base / 2));
  }

  private evictOldestMomentumCandidate(): void {
    let oldestKey: string | null = null;
    let oldestTs = Number.POSITIVE_INFINITY;

    for (const [key, entry] of this.watchlist.entries()) {
      if (entry.addedAt < oldestTs) {
        oldestTs = entry.addedAt;
        oldestKey = key;
      }
    }

    if (oldestKey) {
      this.dropMomentumCandidate(oldestKey, 'evicted_capacity');
    }
  }

  private dropMomentumCandidate(tokenAddress: string, reason: string, extra: Record<string, unknown> = {}): void {
    const entry = this.watchlist.get(tokenAddress);
    if (!entry) {
      return;
    }
    this.watchlist.delete(tokenAddress);
    const ageSeconds = Math.max(0, (Date.now() - (entry.token.launchTime ?? entry.addedAt)) / 1000);
    this.dataRecorder.log('momentum_watch_drop', {
      tokenAddress,
      tokenSymbol: entry.token.tokenSymbol,
      reason,
      attempts: entry.attempts,
      ageSeconds,
      aiRejected: entry.aiRejected,
      ...extra,
    });
  }

  private trackMomentumCandidate(tokenLaunch: TokenLaunch, options?: { aiRejected?: boolean }): void {
    if (!this.config.momentumEnabled) {
      return;
    }

    const tokenAddress = tokenLaunch.tokenAddress;
    if (!tokenAddress) {
      return;
    }

    const liquidity = Number(tokenLaunch.liquidity ?? 0);
    if (!Number.isFinite(liquidity) || liquidity <= 0) {
      return;
    }

    const launchTime = tokenLaunch.launchTime ?? Date.now();
    tokenLaunch.launchTime = launchTime;

    const existing = this.watchlist.get(tokenAddress);
    if (existing) {
      existing.token = { ...existing.token, ...tokenLaunch, launchTime };
      existing.aiRejected = existing.aiRejected || Boolean(options?.aiRejected);
      if (tokenLaunch.price != null && !existing.initialPrice) {
        existing.initialPrice = tokenLaunch.price;
        existing.lastPrice = tokenLaunch.price;
      }
      if (tokenLaunch.liquidity != null && !existing.initialLiquidity) {
        existing.initialLiquidity = tokenLaunch.liquidity;
        existing.lastLiquidity = tokenLaunch.liquidity;
      }
      return;
    }

    if (this.watchlist.size >= this.config.momentumMaxWatchlistSize) {
      this.evictOldestMomentumCandidate();
    }

    const priceValue = Number(tokenLaunch.price ?? Number.NaN);
    const liquidityValue = Number(tokenLaunch.liquidity ?? Number.NaN);

    const entry: MomentumWatchEntry = {
      token: { ...tokenLaunch, launchTime },
      addedAt: Date.now(),
      initialPrice: Number.isFinite(priceValue) && priceValue > 0 ? priceValue : undefined,
      lastPrice: Number.isFinite(priceValue) && priceValue > 0 ? priceValue : undefined,
      initialLiquidity: Number.isFinite(liquidityValue) && liquidityValue > 0 ? liquidityValue : undefined,
      lastLiquidity: Number.isFinite(liquidityValue) && liquidityValue > 0 ? liquidityValue : undefined,
      lastEvaluated: 0,
      aiRejected: Boolean(options?.aiRejected),
      attempts: 0,
      lastDecision: undefined,
    };

    this.watchlist.set(tokenAddress, entry);
    this.dataRecorder.log('momentum_watch_add', {
      tokenAddress,
      tokenSymbol: tokenLaunch.tokenSymbol,
      liquidity,
      aiRejected: Boolean(options?.aiRejected),
      watchlistSize: this.watchlist.size,
    });
  }

  private startMomentumLoop(): void {
    if (!this.config.momentumEnabled) {
      return;
    }

    if (this.momentumTimer) {
      clearInterval(this.momentumTimer);
    }

    const intervalMs = Math.max(5000, this.config.momentumReevalIntervalMs);
    this.momentumTimer = setInterval(() => {
      if (!this.isRunning) {
        return;
      }
      void this.processMomentumWatchlist();
    }, intervalMs);

    void this.processMomentumWatchlist();
  }

  private stopMomentumLoop(): void {
    if (this.momentumTimer) {
      clearInterval(this.momentumTimer);
      this.momentumTimer = null;
    }
  }

  private async processMomentumWatchlist(): Promise<void> {
    if (!this.isRunning || !this.config.momentumEnabled || this.watchlist.size === 0) {
      return;
    }

    for (const [tokenAddress, entry] of Array.from(this.watchlist.entries())) {
      if (!this.isRunning) {
        break;
      }

      try {
        await this.evaluateMomentumCandidate(tokenAddress, entry, Date.now());
      } catch (error) {
        this.logger.error('Momentum evaluation error', {
          token: entry.token.tokenSymbol,
          error: error instanceof Error ? error.message : String(error),
        });
      }
    }
  }

  private async fetchMomentumSnapshot(token: TokenLaunch): Promise<{ price: number; tokensReceived: number } | null> {
    try {
      const probeSol = this.getMomentumProbeAmount();
      const quote = await this.jupiter.getQuoteOnce(this.config.quoteMint || SOL_MINT, token.tokenAddress, probeSol);
      if (!quote) {
        return null;
      }

      const inLamports = Number(quote.inAmount ?? 0);
      const solIn = inLamports / 1e9;
      if (!Number.isFinite(solIn) || solIn <= 0) {
        return null;
      }

      const tokensReceived = await this.jupiter.toUiAmount(token.tokenAddress, quote.outAmount);
      if (!Number.isFinite(tokensReceived) || tokensReceived <= 0) {
        return null;
      }

      const price = solIn / tokensReceived;
      return { price, tokensReceived };
    } catch (error) {
      this.logger.debug('Momentum snapshot failed', {
        token: token.tokenSymbol,
        address: token.tokenAddress,
        error: error instanceof Error ? error.message : String(error),
      });
      return null;
    }
  }

  private async evaluateMomentumCandidate(tokenAddress: string, entry: MomentumWatchEntry, now: number): Promise<void> {
    const ageSeconds = Math.max(0, (now - (entry.token.launchTime ?? entry.addedAt)) / 1000);

    if (ageSeconds > this.config.momentumMaxAgeSeconds) {
      this.dropMomentumCandidate(tokenAddress, 'aged_out', { ageSeconds });
      return;
    }

    if (this.activeTrades.has(tokenAddress) || this.inFlightTrades.has(tokenAddress)) {
      this.dropMomentumCandidate(tokenAddress, 'already_trading');
      return;
    }

    if (ageSeconds < this.config.momentumMinAgeSeconds) {
      return;
    }

    const snapshot = await this.fetchMomentumSnapshot(entry.token);
    if (!snapshot) {
      return;
    }

    entry.token.price = snapshot.price;
    if (!entry.initialPrice || entry.initialPrice <= 0) {
      entry.initialPrice = snapshot.price;
      entry.lastPrice = snapshot.price;
      entry.lastEvaluated = now;
      this.dataRecorder.log('momentum_watch_snapshot', {
        tokenAddress,
        tokenSymbol: entry.token.tokenSymbol,
        price: snapshot.price,
        ageSeconds,
        stage: 'baseline',
      });
      return;
    }

    entry.attempts += 1;

    const priceChangePct = entry.initialPrice > 0
      ? ((snapshot.price - entry.initialPrice) / entry.initialPrice) * 100
      : 0;

    const stepChangePct = entry.lastPrice && entry.lastPrice > 0
      ? ((snapshot.price - entry.lastPrice) / entry.lastPrice) * 100
      : priceChangePct;

    entry.lastPrice = snapshot.price;
    entry.lastEvaluated = now;

    this.dataRecorder.log('momentum_watch_snapshot', {
      tokenAddress,
      tokenSymbol: entry.token.tokenSymbol,
      price: snapshot.price,
      ageSeconds,
      priceChangePct,
      stepChangePct,
      attempts: entry.attempts,
      aiRejected: entry.aiRejected,
      watchlistSize: this.watchlist.size,
    });

    if (priceChangePct < this.config.momentumMinPriceChangePct || stepChangePct < this.config.momentumMinStepChangePct) {
      this.dataRecorder.log('momentum_watch_skip', {
        tokenAddress,
        tokenSymbol: entry.token.tokenSymbol,
        reason: 'threshold_not_met',
        priceChangePct,
        stepChangePct,
        attempts: entry.attempts,
      });
      if (entry.attempts >= this.config.momentumMaxEvaluations) {
        this.dropMomentumCandidate(tokenAddress, 'max_attempts', {
          priceChangePct,
          stepChangePct,
        });
      }
      return;
    }

    if (
      this.config.globalTradeCooldownMs > 0 &&
      now - this.lastGlobalTradeTimestamp < this.config.globalTradeCooldownMs
    ) {
      this.dataRecorder.log('momentum_watch_skip', {
        tokenAddress,
        tokenSymbol: entry.token.tokenSymbol,
        reason: 'global_cooldown',
        remainingMs: this.config.globalTradeCooldownMs - (now - this.lastGlobalTradeTimestamp),
      });
      return;
    }

    if (
      this.config.maxConcurrentTrades > 0 &&
      this.getReservedTradeSlots() >= this.config.maxConcurrentTrades
    ) {
      this.dataRecorder.log('momentum_watch_skip', {
        tokenAddress,
        tokenSymbol: entry.token.tokenSymbol,
        reason: 'max_concurrent_trades',
        activeTrades: this.activeTrades.size,
        reserved: this.getReservedTradeSlots(),
        maxConcurrentTrades: this.config.maxConcurrentTrades,
      });
      return;
    }

    const symbolUpper = entry.token.tokenSymbol.toUpperCase();
    if (this.config.symbolAllowList.length > 0 && !this.config.symbolAllowList.includes(symbolUpper)) {
      this.dropMomentumCandidate(tokenAddress, 'symbol_not_allowed');
      return;
    }
    if (this.config.symbolDenyList.includes(symbolUpper)) {
      this.dropMomentumCandidate(tokenAddress, 'symbol_deny_list');
      return;
    }

    const creatorKey = (entry.token.creator || 'unknown').trim();
    if (creatorKey && this.config.creatorDenyList.includes(creatorKey)) {
      this.dropMomentumCandidate(tokenAddress, 'creator_deny_list');
      return;
    }

    if (this.config.creatorAllowList.length > 0 && !this.config.creatorAllowList.includes(creatorKey)) {
      this.dropMomentumCandidate(tokenAddress, 'creator_not_allowed');
      return;
    }

    const existingHistory = this.creatorTradeHistory.get(creatorKey) || [];
    const history = this.config.creatorWindowMs > 0
      ? existingHistory.filter(ts => now - ts <= this.config.creatorWindowMs * 2)
      : existingHistory.slice(-50);
    this.creatorTradeHistory.set(creatorKey, history);

    if (this.config.creatorCooldownMs > 0 && history.length > 0) {
      const lastTradeTs = history[history.length - 1];
      if (lastTradeTs !== undefined && now - lastTradeTs < this.config.creatorCooldownMs) {
        this.dataRecorder.log('momentum_watch_skip', {
          tokenAddress,
          tokenSymbol: entry.token.tokenSymbol,
          reason: 'creator_cooldown',
          elapsedMs: now - lastTradeTs,
          cooldownMs: this.config.creatorCooldownMs,
        });
        return;
      }
    }

    if (this.config.creatorWindowMs > 0 && this.config.maxCreatorTradesPerWindow > 0) {
      const windowStart = now - this.config.creatorWindowMs;
      const recentTrades = history.filter(ts => ts >= windowStart);
      if (recentTrades.length >= this.config.maxCreatorTradesPerWindow) {
        this.dataRecorder.log('momentum_watch_skip', {
          tokenAddress,
          tokenSymbol: entry.token.tokenSymbol,
          reason: 'creator_window_limit',
          recentCount: recentTrades.length,
          maxTrades: this.config.maxCreatorTradesPerWindow,
        });
        return;
      }
    }

    const liquidityChangePct =
      entry.initialLiquidity && entry.token.liquidity
        ? ((entry.token.liquidity - entry.initialLiquidity) / entry.initialLiquidity) * 100
        : undefined;

    const decision = await this.evaluateWithAI(
      entry.token,
      {
        evaluationContext: 'momentum',
        ageSeconds,
        currentPrice: snapshot.price,
        initialPrice: entry.initialPrice,
        priceChangePct,
        stepChangePct,
        initialLiquidity: entry.initialLiquidity ?? entry.token.liquidity ?? undefined,
        currentLiquidity: entry.token.liquidity ?? entry.lastLiquidity ?? undefined,
        liquidityChangePct,
        aiRejectedAtLaunch: entry.aiRejected,
        watchlistAttempts: entry.attempts,
        sampleWindowSeconds: Math.round(this.config.momentumReevalIntervalMs / 1000),
      },
      {
        minScore: this.config.momentumMinScore,
        confidenceThreshold: Math.max(this.config.aiConfidenceThreshold, 0.5),
      },
    );

    if (decision) {
      entry.lastDecision = decision;
      this.dataRecorder.log('momentum_ai_decision', {
        tokenAddress,
        tokenSymbol: entry.token.tokenSymbol,
        approved: decision.approved,
        score: decision.score,
        risk: decision.risk,
        confidence: decision.confidence,
        priceChangePct,
        stepChangePct,
        attempts: entry.attempts,
      });
    }

    if (decision && !decision.approved) {
      entry.aiRejected = true;
      this.dataRecorder.log('momentum_watch_skip', {
        tokenAddress,
        tokenSymbol: entry.token.tokenSymbol,
        reason: 'ai_rejected',
        score: decision.score,
        risk: decision.risk,
        confidence: decision.confidence,
      });
      if (entry.attempts >= this.config.momentumMaxEvaluations) {
        this.dropMomentumCandidate(tokenAddress, 'ai_rejected', {
          score: decision.score,
          confidence: decision.confidence,
        });
      }
      return;
    }

    this.inFlightTrades.add(tokenAddress);
    try {
      const executed = await this.executeBuy(entry.token, decision ?? undefined, {
        reason: 'momentum',
        priceChangePct,
        ageSeconds,
      });

      if (executed) {
        this.dropMomentumCandidate(tokenAddress, 'executed', {
          priceChangePct,
          stepChangePct,
          ageSeconds,
          score: decision?.score ?? null,
        });
      } else if (entry.attempts >= this.config.momentumMaxEvaluations) {
        this.dropMomentumCandidate(tokenAddress, 'max_attempts', {
          priceChangePct,
          stepChangePct,
        });
      }
    } finally {
      this.releaseReservation(tokenAddress);
    }
  }

  private getReservedTradeSlots(): number {
    return this.activeTrades.size + this.inFlightTrades.size;
  }

  private isActiveCapacityReached(): boolean {
    return this.config.maxConcurrentTrades > 0 && this.activeTrades.size >= this.config.maxConcurrentTrades;
  }

  private updateMonitoringState(): void {
    const shouldPause = this.isActiveCapacityReached();

    if (shouldPause && !this.monitoringPaused) {
      this.monitoringPaused = true;
      this.capacityAlerted = true;
      this.logger.info('Active trade limit reached; pausing new token entries.', {
        activeTrades: this.activeTrades.size,
        limit: this.config.maxConcurrentTrades,
        watchlistSize: this.watchlist.size,
      });
      this.logger.setSilentMode(true);
      this.pumpPortal.setEventLogging(false);
    } else if (!shouldPause && this.monitoringPaused) {
      this.monitoringPaused = false;
      this.capacityAlerted = false;
      this.logger.info('Monitoring resumed; capacity available for new tokens.', {
        activeTrades: this.activeTrades.size,
        limit: this.config.maxConcurrentTrades,
      });
      this.logger.setSilentMode(false);
      this.pumpPortal.setEventLogging(true);
    }
  }

  private releaseReservation(tokenAddress: string): void {
    if (this.inFlightTrades.delete(tokenAddress)) {
      if (this.capacityAlerted && this.getReservedTradeSlots() < this.config.maxConcurrentTrades) {
        this.capacityAlerted = false;
        this.logger.info('Capacity available for new trades again.', {
          active: this.activeTrades.size,
          reserved: this.getReservedTradeSlots(),
          max: this.config.maxConcurrentTrades,
        });
      }
    }
  }

  private async evaluateWithAI(
    tokenLaunch: TokenLaunch,
    extras: Partial<AIFilterFeatures> = {},
    guardOverrides?: DeepseekGuardOverrides,
  ): Promise<AIFilterDecision | null> {
    if (!this.deepseek?.isEnabled()) {
      return null;
    }

    try {
      const defaultAgeSeconds = Math.max(0, (Date.now() - (tokenLaunch.launchTime ?? Date.now())) / 1000);
      const liquidity = extras.liquidity ?? tokenLaunch.liquidity ?? 0;
      const marketCap = extras.marketCap ?? tokenLaunch.marketCap ?? undefined;
      const price = extras.currentPrice ?? extras.price ?? tokenLaunch.price ?? undefined;
      const features: AIFilterFeatures = {
        tokenAddress: tokenLaunch.tokenAddress,
        tokenSymbol: tokenLaunch.tokenSymbol,
        liquidity,
        marketCap,
        price,
        initialPrice: extras.initialPrice ?? tokenLaunch.price ?? undefined,
        currentPrice: price,
        priceChangePct: extras.priceChangePct ?? undefined,
        stepChangePct: extras.stepChangePct ?? undefined,
        initialLiquidity: extras.initialLiquidity ?? tokenLaunch.liquidity ?? undefined,
        currentLiquidity: extras.currentLiquidity ?? tokenLaunch.liquidity ?? undefined,
        liquidityChangePct: extras.liquidityChangePct ?? undefined,
        initialBuy: extras.initialBuy ?? tokenLaunch.initialBuy ?? undefined,
        solAmount: extras.solAmount ?? tokenLaunch.solAmount ?? undefined,
        creator: extras.creator ?? tokenLaunch.creator ?? undefined,
        ageSeconds: extras.ageSeconds ?? defaultAgeSeconds,
        evaluationContext: extras.evaluationContext ?? 'launch',
        aiRejectedAtLaunch: extras.aiRejectedAtLaunch ?? false,
        watchlistAttempts: extras.watchlistAttempts ?? undefined,
        sampleWindowSeconds: extras.sampleWindowSeconds ?? undefined,
        activeTrades: this.activeTrades.size,
        maxConcurrentTrades: this.config.maxConcurrentTrades,
        stopLossPercentage: this.config.stopLossPercentage,
        takeProfitPercentage: this.config.takeProfitPercentage,
      };

      const decision = await this.deepseek.evaluate(features, guardOverrides);
      if (decision) {
        this.logger.debug('Deepseek decision', {
          token: tokenLaunch.tokenSymbol,
          context: features.evaluationContext,
          approved: decision.approved,
          score: decision.score,
          risk: decision.risk,
          confidence: decision.confidence,
        });
        this.dataRecorder.log('ai_decision', {
          tokenAddress: tokenLaunch.tokenAddress,
          tokenSymbol: tokenLaunch.tokenSymbol,
          context: features.evaluationContext,
          approved: decision.approved,
          score: decision.score,
          risk: decision.risk,
          confidence: decision.confidence,
          priceChangePct: features.priceChangePct ?? null,
          stepChangePct: features.stepChangePct ?? null,
        });
      }
      return decision ?? null;
    } catch (error) {
      this.logger.error('Deepseek evaluation failed', error);
      this.dataRecorder.log('ai_error', {
        tokenAddress: tokenLaunch.tokenAddress,
        tokenSymbol: tokenLaunch.tokenSymbol,
        context: extras.evaluationContext ?? 'launch',
        error: error instanceof Error ? error.message : String(error),
      });
      return null;
    }
  }

  private upgradeTradeRecord(raw: any): Trade {
    const tokenAmount = typeof raw.tokenAmount === 'number'
      ? raw.tokenAmount
      : (typeof raw.buyAmount === 'number' && typeof raw.buyPrice === 'number' && raw.buyPrice > 0
        ? raw.buyAmount / raw.buyPrice
        : 0);

    const remainingTokenAmount = typeof raw.remainingTokenAmount === 'number'
      ? raw.remainingTokenAmount
      : tokenAmount;

    const remainingCostBasis = typeof raw.remainingCostBasis === 'number'
      ? raw.remainingCostBasis
      : (typeof raw.buyAmount === 'number' ? raw.buyAmount : 0);

    const realizedPnL = typeof raw.realizedPnL === 'number'
      ? raw.realizedPnL
      : (typeof raw.pnl === 'number' ? raw.pnl : 0);

    return {
      ...raw,
      tokenAmount,
      remainingTokenAmount,
      remainingCostBasis,
      realizedPnL,
      partialTakeProfitExecuted: raw.partialTakeProfitExecuted ?? false,
      aiDecision: raw.aiDecision ?? undefined,
    } as Trade;
  }
// === Direct WS subscriber (fallback) ===========
  private wirePumpPortalFallback() {
    const url = (this.config.pumpPortalWsUrl || 'wss://pumpportal.fun/api/data').trim();
    this.logger.info(`PumpPortal[FALLBACK]: connecting ${url}`);

    try {
      this.ws = new WebSocket(url);
    } catch (e) {
      this.logger.error('PumpPortal[FALLBACK]: failed to create WebSocket:', e);
      return;
    }

    this.ws.on('open', () => {
      this.logger.info('PumpPortal[FALLBACK]: WS open, subscribing...');
      this.reconnectAttempts = 0;
      try {
        this.ws!.send(JSON.stringify({ method: 'subscribeNewToken' }));
      } catch (e) {
        this.logger.error('PumpPortal[FALLBACK]: subscribe error:', e);
      }
    });

    this.ws.on('message', async (buf) => {
      try {
        const text = buf.toString();
        const lines = text.split('\n').filter(Boolean);
        for (const line of lines) {
          const msg = JSON.parse(line);
          const short = {
            method: msg?.method,
            symbol: msg?.symbol || msg?.name,
            mint: msg?.mint || msg?.tokenAddress || msg?.mintAddress,
          };
          this.logger.info('PumpPortal[FALLBACK] event:', short);
          this.lastPumpEventTs = Date.now();

          const mintAddr = msg?.mint || msg?.tokenAddress || msg?.mintAddress;
          if (mintAddr) {
            const tokenLaunch: TokenLaunch = {
              tokenAddress: String(mintAddr),
              tokenSymbol: String(msg?.symbol || msg?.name || 'UNKNOWN'),
              liquidity: Number(
                msg?.liquidity ??
                msg?.solAmount ??       // often present on txType: "create"
                msg?.initialBuy ??      // fallback
                0
              ),
              launchTime: Date.now(),
              status: 'open',
            } as TokenLaunch;

            await this.handleTokenLaunch(tokenLaunch);
          }
        }
      } catch (e) {
        this.logger.error('PumpPortal[FALLBACK]: message parse error:', e);
      }
    });

    this.ws.on('close', (code, reason) => {
      this.logger.warn(`PumpPortal[FALLBACK]: closed code=${code} reason=${reason?.toString?.()}`);
      this.scheduleFallbackReconnect();
    });

    this.ws.on('error', (err) => {
      this.logger.error('PumpPortal[FALLBACK]: WS error:', (err as any)?.message || err);
      try { this.ws?.close(); } catch {}
    });
  }

  private scheduleFallbackReconnect() {
    this.reconnectAttempts++;
    const delay = Math.min(1000 * 2 ** Math.min(this.reconnectAttempts, 5), 30000);
    this.logger.info(`PumpPortal[FALLBACK]: reconnecting in ${delay}ms...`);
    setTimeout(() => this.wirePumpPortalFallback(), delay);
  }

  // === Watchdog to enable fallback if no events ===
  private startWatchdog() {
    const THRESHOLD_MS = 20000;
    if (this.watchdogTimer) clearInterval(this.watchdogTimer);
    this.watchdogTimer = setInterval(() => {
      if (!this.isRunning) return;
      const gap = Date.now() - this.lastPumpEventTs;
      if (gap > THRESHOLD_MS) {
        this.logger.warn(`PumpPortal: no events for ${Math.round(gap / 1000)}s — enabling fallback subscriber`);
        if (!this.ws || this.ws.readyState !== WebSocket.OPEN) {
          this.wirePumpPortalFallback();
        }
      }
    }, 5000);
  }

  // ========================================================

  private async handleTokenLaunch(tokenLaunch: TokenLaunch): Promise<void> {
    const now = Date.now();
    const tokenKey = tokenLaunch.tokenAddress;

    try {
      this.updateMonitoringState();
      const monitoringPaused = this.monitoringPaused;

      this.dataRecorder.log('pump_event', {
        tokenAddress: tokenLaunch.tokenAddress,
        tokenSymbol: tokenLaunch.tokenSymbol,
        liquidity: tokenLaunch.liquidity ?? null,
        initialBuy: tokenLaunch.initialBuy ?? null,
        solAmount: tokenLaunch.solAmount ?? null,
        marketCap: tokenLaunch.marketCap ?? null,
        price: tokenLaunch.price ?? null,
        creator: tokenLaunch.creator ?? null,
        txSignature: tokenLaunch.txSignature ?? null,
        txType: tokenLaunch.txType ?? null,
        activeTrades: this.activeTrades.size,
        inFlightTrades: this.inFlightTrades.size,
        reservedSlots: this.getReservedTradeSlots(),
        maxConcurrentTrades: this.config.maxConcurrentTrades,
        oneTokenAtATime: this.config.oneTokenAtATime,
        monitoringPaused,
      });

      this.trackMomentumCandidate(tokenLaunch);

      if (monitoringPaused) {
        this.logger.debug('Monitoring paused at active trade capacity; skipping new launch.', {
          token: tokenLaunch.tokenSymbol,
          tokenAddress: tokenKey,
          activeTrades: this.activeTrades.size,
          limit: this.config.maxConcurrentTrades,
        });
        this.dataRecorder.log('pump_event_skipped', {
          tokenAddress: tokenKey,
          reason: 'monitoring_paused',
          activeTrades: this.activeTrades.size,
          maxConcurrentTrades: this.config.maxConcurrentTrades,
        });
        return;
      }

      if (
        this.config.globalTradeCooldownMs > 0 &&
        now - this.lastGlobalTradeTimestamp < this.config.globalTradeCooldownMs
      ) {
        this.logger.debug('Global trade cooldown active, skipping launch.', {
          cooldownMs: this.config.globalTradeCooldownMs,
          elapsedMs: now - this.lastGlobalTradeTimestamp,
        });
        this.dataRecorder.log('pump_event_skipped', {
          tokenAddress: tokenKey,
          reason: 'global_cooldown',
          cooldownMs: this.config.globalTradeCooldownMs,
          elapsedMs: now - this.lastGlobalTradeTimestamp,
        });
        return;
      }

      if (this.activeTrades.has(tokenKey)) {
        this.logger.debug('Already trading this token:', tokenLaunch.tokenSymbol);
        this.dataRecorder.log('pump_event_skipped', {
          tokenAddress: tokenKey,
          reason: 'already_trading',
        });
        return;
      }

      if (this.inFlightTrades.has(tokenKey)) {
        this.logger.debug('Trade execution already pending for token:', tokenLaunch.tokenSymbol);
        this.dataRecorder.log('pump_event_skipped', {
          tokenAddress: tokenKey,
          reason: 'pending_execution',
        });
        return;
      }

      if (
        this.config.maxConcurrentTrades > 0 &&
        this.getReservedTradeSlots() >= this.config.maxConcurrentTrades
      ) {
        if (!this.capacityAlerted) {
          this.logger.warn('Max concurrent trades reached, pausing new entries.', {
            activeTrades: this.activeTrades.size,
            inFlight: this.inFlightTrades.size,
            maxConcurrentTrades: this.config.maxConcurrentTrades,
          });
          this.capacityAlerted = true;
        }
        this.dataRecorder.log('pump_event_skipped', {
          tokenAddress: tokenKey,
          reason: 'max_concurrent_trades',
          activeTrades: this.activeTrades.size,
          inFlight: this.inFlightTrades.size,
          maxConcurrentTrades: this.config.maxConcurrentTrades,
        });
        return;
      }

      this.inFlightTrades.add(tokenKey);

      try {
        const symbolUpper = tokenLaunch.tokenSymbol.toUpperCase();
        const creatorKey = (tokenLaunch.creator || 'unknown').trim();

        if (this.config.symbolAllowList.length > 0 && !this.config.symbolAllowList.includes(symbolUpper)) {
          this.logger.debug('Symbol not in allow list, skipping:', symbolUpper);
          this.dataRecorder.log('pump_event_skipped', {
            tokenAddress: tokenKey,
            reason: 'symbol_not_allowed',
            tokenSymbol: symbolUpper,
          });
          return;
        }

        if (this.config.symbolDenyList.includes(symbolUpper)) {
          this.logger.warn('Symbol on deny list, skipping:', symbolUpper);
          this.dataRecorder.log('pump_event_skipped', {
            tokenAddress: tokenKey,
            reason: 'symbol_deny_list',
            tokenSymbol: symbolUpper,
          });
          return;
        }

        if (creatorKey && this.config.creatorDenyList.includes(creatorKey)) {
          this.logger.warn('Creator on deny list, skipping:', { creator: creatorKey });
          this.dataRecorder.log('pump_event_skipped', {
            tokenAddress: tokenKey,
            reason: 'creator_deny_list',
            creator: creatorKey,
          });
          return;
        }

        if (this.config.creatorAllowList.length > 0 && !this.config.creatorAllowList.includes(creatorKey)) {
          this.logger.debug('Creator not in allow list, skipping:', { creator: creatorKey });
          this.dataRecorder.log('pump_event_skipped', {
            tokenAddress: tokenKey,
            reason: 'creator_not_allowed',
            creator: creatorKey,
          });
          return;
        }

        const liquidity = tokenLaunch.liquidity ?? 0;
        if (liquidity < this.config.minLiquiditySol) {
          this.logger.debug('Liquidity below threshold, skipping:', {
            symbol: symbolUpper,
            liquidity,
            minLiquidity: this.config.minLiquiditySol,
          });
          this.dataRecorder.log('pump_event_skipped', {
            tokenAddress: tokenKey,
            reason: 'liquidity_below_min',
            liquidity,
            minLiquidity: this.config.minLiquiditySol,
          });
          return;
        }

        const initialBuy = tokenLaunch.initialBuy ?? tokenLaunch.solAmount ?? liquidity;
        if (initialBuy < this.config.minInitialBuySol) {
          this.logger.debug('Initial buy below threshold, skipping:', {
            symbol: symbolUpper,
            initialBuy,
            minInitialBuy: this.config.minInitialBuySol,
          });
          this.dataRecorder.log('pump_event_skipped', {
            tokenAddress: tokenKey,
            reason: 'initial_buy_below_min',
            initialBuy,
            minInitialBuy: this.config.minInitialBuySol,
          });
          return;
        }

        if (tokenLaunch.solAmount != null && tokenLaunch.solAmount < this.config.minSolAmount) {
          this.logger.debug('SOL amount below threshold, skipping:', {
            symbol: symbolUpper,
            solAmount: tokenLaunch.solAmount,
            minSolAmount: this.config.minSolAmount,
          });
          this.dataRecorder.log('pump_event_skipped', {
            tokenAddress: tokenKey,
            reason: 'sol_amount_below_min',
            solAmount: tokenLaunch.solAmount,
            minSolAmount: this.config.minSolAmount,
          });
          return;
        }

        const existingHistory = this.creatorTradeHistory.get(creatorKey) || [];
        const history = this.config.creatorWindowMs > 0
          ? existingHistory.filter(ts => now - ts <= this.config.creatorWindowMs * 2)
          : existingHistory.slice(-50);
        this.creatorTradeHistory.set(creatorKey, history);
        if (this.config.creatorCooldownMs > 0 && history.length > 0) {
          const lastTradeTs = history[history.length - 1];
          if (lastTradeTs !== undefined && now - lastTradeTs < this.config.creatorCooldownMs) {
            this.logger.debug('Creator cooldown active, skipping:', {
              creator: creatorKey,
              elapsedMs: now - lastTradeTs,
              cooldownMs: this.config.creatorCooldownMs,
            });
            this.dataRecorder.log('pump_event_skipped', {
              tokenAddress: tokenKey,
              reason: 'creator_cooldown',
              creator: creatorKey,
              elapsedMs: now - lastTradeTs,
              cooldownMs: this.config.creatorCooldownMs,
            });
            return;
          }
        }

        if (this.config.creatorWindowMs > 0 && this.config.maxCreatorTradesPerWindow > 0) {
          const windowStart = now - this.config.creatorWindowMs;
          const recentTrades = history.filter(ts => ts >= windowStart);
          if (recentTrades.length >= this.config.maxCreatorTradesPerWindow) {
            this.logger.debug('Creator trade window limit reached, skipping:', {
              creator: creatorKey,
              recentCount: recentTrades.length,
              maxTrades: this.config.maxCreatorTradesPerWindow,
            });
            this.dataRecorder.log('pump_event_skipped', {
              tokenAddress: tokenKey,
              reason: 'creator_window_limit',
              creator: creatorKey,
              recentCount: recentTrades.length,
              maxTrades: this.config.maxCreatorTradesPerWindow,
            });
            return;
          }
        }

        const aiDecision = await this.evaluateWithAI(tokenLaunch);
        if (aiDecision) {
          if (!aiDecision.approved) {
            this.trackMomentumCandidate(tokenLaunch, { aiRejected: true });
            this.logger.info('Deepseek filter rejected token', {

              token: tokenLaunch.tokenSymbol,
              score: aiDecision.score,
              risk: aiDecision.risk,
              confidence: aiDecision.confidence,
            });
            this.dataRecorder.log('pump_event_skipped', {
              tokenAddress: tokenKey,
              reason: 'ai_filter_rejected',
              aiScore: aiDecision.score,
              aiRisk: aiDecision.risk,
              aiConfidence: aiDecision.confidence,
            });
            return;
          }
        }

        if (this.config.autoBuyDelay > 0) {
          this.logger.info(`Waiting ${this.config.autoBuyDelay}ms before buying...`);
          await new Promise((r) => setTimeout(r, this.config.autoBuyDelay));
        }

        const buyExecuted = await this.executeBuy(tokenLaunch, aiDecision ?? undefined);
        if (!buyExecuted) {
          return;
        }
      } finally {
        this.releaseReservation(tokenKey);
      }
    } catch (error) {
      this.logger.error('Error handling token launch:', error);
    }
  }

  /** Proxy helper around JupiterService.waitForRoute using configured defaults. */
  private async waitForRoute(
    inputMint: string,
    outputMint: string,
    amountSol: number,
    maxWaitMs?: number,
    pollMs?: number
  ): Promise<JupiterQuote | null> {
    const waitWindow = typeof maxWaitMs === 'number' ? maxWaitMs : this.config.routeWaitMs;
    const pollInterval = typeof pollMs === 'number' ? pollMs : this.config.routePollMs;
    return this.jupiter.waitForRoute(inputMint, outputMint, amountSol, waitWindow, pollInterval);
  }

  private async executeBuy(tokenLaunch: TokenLaunch, aiDecision?: AIFilterDecision, context?: { reason?: 'launch' | 'momentum'; priceChangePct?: number; ageSeconds?: number; }): Promise<boolean> {
    const reason = context?.reason ?? 'launch';
    try {
      const buyAmount = this.config.buyAmountSol;
      const attemptId = `${tokenLaunch.tokenAddress}:${Date.now()}`;
      const creatorKey = (tokenLaunch.creator || 'unknown').trim();

      if (!context || context.reason !== 'momentum') {
        this.watchlist.delete(tokenLaunch.tokenAddress);
      }

      const solBalance = await this.jupiter.getBalance(SOL_MINT);
      if (solBalance < buyAmount) {
        this.logger.error('Insufficient SOL balance for buy:', {
          required: buyAmount,
          available: solBalance,
          reason,
        });
        this.dataRecorder.log('trade_result', {
          attemptId,
          tokenAddress: tokenLaunch.tokenAddress,
          tokenSymbol: tokenLaunch.tokenSymbol,
          status: 'insufficient_balance',
          required: buyAmount,
          available: solBalance,
          reason,
        });
        return false;
      }

      this.dataRecorder.log('trade_attempt', {
        attemptId,
        tokenAddress: tokenLaunch.tokenAddress,
        tokenSymbol: tokenLaunch.tokenSymbol,
        buyAmount,
        liquidity: tokenLaunch.liquidity ?? null,
        initialBuy: tokenLaunch.initialBuy ?? null,
        solAmount: tokenLaunch.solAmount ?? null,
        activeTrades: this.activeTrades.size,
        solBalance,
        creator: creatorKey,
        tradeLive: this.config.tradeLive,
        minFreeSolBalance: this.config.minFreeSolBalance,
        projectedRemainingSol: solBalance - buyAmount,
        aiScore: aiDecision?.score ?? null,
        aiRisk: aiDecision?.risk ?? null,
        aiConfidence: aiDecision?.confidence ?? null,
        reason,
        momentumPriceChangePct: context?.priceChangePct ?? null,
        momentumAgeSeconds: context?.ageSeconds ?? null,
      });

      if (solBalance - buyAmount < this.config.minFreeSolBalance) {
        this.logger.warn('Skipping buy: remaining SOL would fall below reserve.', {
          buyAmount,
          solBalance,
          minFreeSolBalance: this.config.minFreeSolBalance,
          reason,
        });
        this.dataRecorder.log('trade_result', {
          attemptId,
          tokenAddress: tokenLaunch.tokenAddress,
          tokenSymbol: tokenLaunch.tokenSymbol,
          status: 'insufficient_reserve',
          buyAmount,
          solBalance,
          minFreeSolBalance: this.config.minFreeSolBalance,
          reason,
        });
        return false;
      }

      this.logger.trade('Executing buy order:', {
        token: tokenLaunch.tokenSymbol,
        amount: buyAmount,
        address: tokenLaunch.tokenAddress,
        reason,
        priceChangePct: context?.priceChangePct ?? null,
        ageSeconds: context?.ageSeconds ?? null,
      });

      let quote = await this.waitForRoute(
        this.config.quoteMint || SOL_MINT,
        tokenLaunch.tokenAddress,
        buyAmount,
        this.config.routeWaitMs,
        this.config.routePollMs,
      );

      if (!quote) {
        for (let attempt = 1; attempt <= this.config.routeRetryAttempts; attempt++) {
          if (this.config.routeRetryDelayMs > 0) {
            this.logger.warn(
              `Jupiter route still unavailable. Retry ${attempt}/${this.config.routeRetryAttempts} in ${this.config.routeRetryDelayMs}ms...`,
              { token: tokenLaunch.tokenSymbol, mint: tokenLaunch.tokenAddress, reason },
            );
            await new Promise((resolve) => setTimeout(resolve, this.config.routeRetryDelayMs));
          }

          quote = await this.waitForRoute(
            this.config.quoteMint || SOL_MINT,
            tokenLaunch.tokenAddress,
            buyAmount,
            this.config.routeRetryWaitMs,
            this.config.routePollMs,
          );

          if (quote) {
            break;
          }
        }
      }

      if (!quote) {
        this.logger.error('Buy aborted: no Jupiter route became available in time.', { reason });
        await this.telegram.notifyError('No Jupiter route yet (timeout)', 'Buy Route');
        this.dataRecorder.log('trade_result', {
          attemptId,
          tokenAddress: tokenLaunch.tokenAddress,
          tokenSymbol: tokenLaunch.tokenSymbol,
          status: 'quote_timeout',
          retries: this.config.routeRetryAttempts,
          reason,
        });
        return false;
      }

      this.dataRecorder.log('quote_ready', {
        attemptId,
        tokenAddress: tokenLaunch.tokenAddress,
        tokenSymbol: tokenLaunch.tokenSymbol,
        inAmount: quote.inAmount,
        outAmount: quote.outAmount,
        priceImpactPct: quote.priceImpactPct,
        routePlanLegs: quote.routePlan?.length ?? 0,
        reason,
      });

      if (!this.config.tradeLive) {
        const simulatedReceivedRaw = Number(quote.outAmount || 0);
        this.logger.trade('Simulated buy skipped (TRADE_LIVE=false):', {
          token: tokenLaunch.tokenSymbol,
          amount: buyAmount,
          quotedOutAmount: simulatedReceivedRaw,
          reason,
        });
        this.dataRecorder.log('trade_result', {
          attemptId,
          tokenAddress: tokenLaunch.tokenAddress,
          tokenSymbol: tokenLaunch.tokenSymbol,
          status: 'simulated',
          quotedOutAmount: simulatedReceivedRaw,
          buyAmount,
          reason,
          momentumPriceChangePct: context?.priceChangePct ?? null,
          momentumAgeSeconds: context?.ageSeconds ?? null,
        });
        return false;
      }

      let swapResult;
      const doSwap = (this.jupiter as any).doSwap;
      if (typeof doSwap === 'function') {
        swapResult = await doSwap.call(this.jupiter, quote);
      } else {
        swapResult = await this.jupiter.swap(
          this.config.quoteMint || SOL_MINT,
          tokenLaunch.tokenAddress,
          buyAmount
        );
      }

      if (!swapResult.success) {
        this.logger.error('Buy order failed:', swapResult.error);
        await this.telegram.notifyError(swapResult.error || 'Unknown error', 'Buy Order');
        this.dataRecorder.log('trade_result', {
          attemptId,
          tokenAddress: tokenLaunch.tokenAddress,
          tokenSymbol: tokenLaunch.tokenSymbol,
          status: 'swap_failed',
          error: swapResult.error || 'unknown',
          reason,
        });
        return false;
      }

      const received = Number(swapResult.outputAmount ?? 0);
      const buyPrice = received > 0 ? buyAmount / received : 0;
      const stopLossPrice = buyPrice * (1 - this.config.stopLossPercentage / 100);
      const takeProfitPrice = buyPrice * (1 + this.config.takeProfitPercentage / 100);

      const trade: Trade = {
        id: Date.now().toString(),
        tokenAddress: tokenLaunch.tokenAddress,
        tokenSymbol: tokenLaunch.tokenSymbol,
        buyPrice,
        buyAmount,
        buyTimestamp: Date.now(),
        tokenAmount: received,
        remainingTokenAmount: received,
        remainingCostBasis: buyAmount,
        realizedPnL: 0,
        partialTakeProfitExecuted: false,
        aiDecision,
        entryReason: reason,
        momentumPriceChangePct: context?.priceChangePct,
        momentumAgeSeconds: context?.ageSeconds,
        status: 'open',
        stopLossPrice,
        takeProfitPrice,
      };

      this.activeTrades.set(tokenLaunch.tokenAddress, trade);
      this.updateMonitoringState();
      this.saveTrades();

      if (context?.reason === 'momentum') {
        this.watchlist.delete(tokenLaunch.tokenAddress);
      }

      const completionTs = Date.now();
      this.lastGlobalTradeTimestamp = completionTs;
      const history = this.creatorTradeHistory.get(creatorKey) || [];
      history.push(completionTs);
      const windowStart = completionTs - this.config.creatorWindowMs;
      const prunedHistory = this.config.creatorWindowMs > 0
        ? history.filter(ts => ts >= windowStart)
        : history.slice(-50);
      this.creatorTradeHistory.set(creatorKey, prunedHistory);

      await this.telegram.notifyBuy(trade, swapResult);

      this.dataRecorder.log('trade_result', {
        attemptId,
        tokenAddress: tokenLaunch.tokenAddress,
        tokenSymbol: tokenLaunch.tokenSymbol,
        status: 'success',
        buyAmount,
        received,
        buyPrice,
        stopLossPrice,
        takeProfitPrice,
        signature: swapResult.signature ?? null,
        creator: creatorKey,
        aiScore: aiDecision?.score ?? null,
        aiRisk: aiDecision?.risk ?? null,
        aiConfidence: aiDecision?.confidence ?? null,
        reason,
        momentumPriceChangePct: context?.priceChangePct ?? null,
        momentumAgeSeconds: context?.ageSeconds ?? null,
      });

      this.logger.trade('Buy order executed successfully:', {
        token: tokenLaunch.tokenSymbol,
        amount: buyAmount,
        received,
        price: buyPrice,
        stopLoss: stopLossPrice,
        takeProfit: takeProfitPrice,
        reason,
      });

      return true;
    } catch (error) {
      this.logger.error('Error executing buy order:', error);
      await this.telegram.notifyError(error instanceof Error ? error.message : 'Unknown error', 'Buy Execution');
      return false;
    }
  }


  public async monitorTrades(): Promise<void> {
    for (const [, trade] of this.activeTrades.entries()) {
      try {
        if (trade.status !== 'open') {
          continue;
        }

        const currentPrice = await this.getCurrentPrice(trade.tokenAddress);
        if (currentPrice == null) {
          continue;
        }

        if (currentPrice <= trade.stopLossPrice) {
          await this.executeSell(trade, 'stop_loss');
          continue;
        }

        if (currentPrice >= trade.takeProfitPrice) {
          const canPartial = this.config.partialTakeProfitEnabled && trade.partialTakeProfitExecuted !== true;

          if (canPartial) {
            const partialSucceeded = await this.executeSell(trade, 'take_profit_partial', {
              fraction: this.config.partialTakeProfitFraction,
            });

            if (partialSucceeded) {
              trade.partialTakeProfitExecuted = true;
              if (this.config.breakEvenStopLossAfterPartial) {
                trade.stopLossPrice = Math.max(trade.stopLossPrice, trade.buyPrice);
              }
              const finalTarget = trade.buyPrice * (1 + this.config.takeProfitFinalPercentage / 100);
              trade.takeProfitPrice = Math.max(finalTarget, trade.takeProfitPrice);
              this.saveTrades();
            }
            continue;
          }

          await this.executeSell(trade, 'take_profit');
          continue;
        }
      } catch (error) {
        this.logger.error('Error monitoring trade:', {
          token: trade.tokenSymbol,
          error: error instanceof Error ? error.message : 'Unknown error',
        });
      }
    }
  }

  private async executeSell(
    trade: Trade,
    reason: 'stop_loss' | 'take_profit' | 'manual' | 'take_profit_partial',
    options?: { fraction?: number }
  ): Promise<boolean> {
    try {
      const applyDelay = this.config.sellDelay > 0 && reason !== 'take_profit_partial';
      if (applyDelay) {
        this.logger.info(`Waiting ${this.config.sellDelay}ms before selling...`);
        await new Promise(resolve => setTimeout(resolve, this.config.sellDelay));
      }

      const fractionRaw = options?.fraction ?? 1;
      const fraction = Math.min(1, Math.max(0.0001, fractionRaw));

      const walletBalance = await this.jupiter.getBalance(trade.tokenAddress);
      const recordedRemaining = trade.remainingTokenAmount ?? trade.tokenAmount ?? walletBalance;
      const available = Math.min(walletBalance, recordedRemaining > 0 ? recordedRemaining : walletBalance);

      if (available <= 0) {
        this.logger.error('No token balance to sell:', trade.tokenSymbol);
        this.activeTrades.delete(trade.tokenAddress);
        trade.status = 'stopped';
        trade.sellTimestamp = Date.now();
        this.completedTrades.push(trade);
        this.saveTrades();
        this.updateMonitoringState();
        this.dataRecorder.log('trade_result', {
          tokenAddress: trade.tokenAddress,
          tokenSymbol: trade.tokenSymbol,
          status: 'no_balance',
        });
        return false;
      }

      const amountToSell = fraction >= 0.999 ? available : available * fraction;
      if (amountToSell <= 0) {
        this.logger.warn('Computed sell amount negligible, skipping sell.', {
          token: trade.tokenSymbol,
          requestedFraction: fractionRaw,
          available,
        });
        return false;
      }

      this.logger.trade('Executing sell order:', {
        token: trade.tokenSymbol,
        reason,
        requestedFraction: fraction,
        balance: available,
        amountToSell,
      });

      const swapResult = await this.jupiter.swap(
        trade.tokenAddress,
        this.config.quoteMint || SOL_MINT,
        amountToSell
      );

      if (!swapResult.success) {
        this.logger.error('Sell order failed:', swapResult.error);
        await this.telegram.notifyError(swapResult.error || 'Unknown error', 'Sell Order');
        return false;
      }

      const soldTokens = swapResult.inputAmount ?? amountToSell;
      const soldAmount = swapResult.outputAmount ?? 0;
      const avgCostPerToken = trade.tokenAmount > 0 ? trade.buyAmount / trade.tokenAmount : trade.buyPrice;
      const costForSold = Math.min(trade.remainingCostBasis ?? trade.buyAmount, avgCostPerToken * soldTokens);
      const realized = soldAmount - costForSold;

      const remainingBefore = trade.remainingTokenAmount ?? trade.tokenAmount ?? 0;
      trade.remainingTokenAmount = Math.max(0, remainingBefore - soldTokens);
      trade.remainingCostBasis = Math.max(0, (trade.remainingCostBasis ?? trade.buyAmount) - costForSold);
      trade.realizedPnL = (trade.realizedPnL ?? 0) + realized;
      trade.sellAmount = (trade.sellAmount ?? 0) + soldAmount;
      trade.sellPrice = soldTokens > 0 ? soldAmount / soldTokens : trade.sellPrice;
      trade.pnl = trade.realizedPnL;
      trade.pnlPercentage = trade.buyAmount > 0 ? (trade.realizedPnL / trade.buyAmount) * 100 : 0;

      const isFinal = trade.remainingTokenAmount <= Math.max(1e-9, (trade.tokenAmount || 0) * 0.001) || fraction >= 0.999;

      if (isFinal) {
        trade.sellTimestamp = Date.now();
        trade.status = 'closed';
        this.activeTrades.delete(trade.tokenAddress);
        this.completedTrades.push(trade);
      } else {
        if (reason === 'take_profit_partial') {
          trade.partialTakeProfitExecuted = true;
        }
        trade.status = 'open';
      }

      this.saveTrades();
      this.updateMonitoringState();

      const statusLabel = isFinal
        ? (reason === 'take_profit_partial' ? 'take_profit' : reason)
        : `${reason}_partial`;

      this.dataRecorder.log('trade_result', {
        tokenAddress: trade.tokenAddress,
        tokenSymbol: trade.tokenSymbol,
        status: statusLabel,
        soldAmount,
        soldTokens,
        remainingTokenAmount: trade.remainingTokenAmount,
        pnl: trade.realizedPnL,
        pnlPercentage: trade.pnlPercentage,
      });

      if (isFinal) {
        if (reason === 'stop_loss') {
          await this.telegram.notifyStopLoss(trade, swapResult);
        } else if (reason === 'take_profit' || reason === 'take_profit_partial') {
          await this.telegram.notifyTakeProfit(trade, swapResult);
        } else {
          await this.telegram.notifySell(trade, swapResult);
        }
      }

      return true;
    } catch (error) {
      this.logger.error('Error executing sell order:', error);
      await this.telegram.notifyError(error instanceof Error ? error.message : 'Unknown error', 'Sell Execution');
      return false;
    }
  }

  private async getCurrentPrice(tokenAddress: string): Promise<number | null> {
    try {
      const quoteMint = this.config.quoteMint || SOL_MINT;
      const probeSol = Math.max(0.0001, this.config.priceProbeAmount ?? 0.001);
      const probeTokens = Math.max(0.000001, this.config.priceProbeTokenAmount ?? 10);
      const waitMs = Math.min(5_000, Number(this.config.routeWaitMs ?? 5_000));
      const pollMs = Math.min(1_000, Number(this.config.routePollMs ?? 1_000));

      const trySolToToken = async (): Promise<number | null> => {
        let quote = await this.jupiter.getQuoteOnce(quoteMint, tokenAddress, probeSol);
        if (!quote) {
          quote = await this.waitForRoute(quoteMint, tokenAddress, probeSol, waitMs, pollMs);
        }
        if (!quote) {
          return null;
        }

        const tokensReceived = await this.jupiter.toUiAmount(tokenAddress, quote.outAmount ?? 0);
        if (!Number.isFinite(tokensReceived) || tokensReceived <= 0) {
          return null;
        }

        return probeSol / tokensReceived;
      };

      const tryTokenToSol = async (): Promise<number | null> => {
        let quote = await this.jupiter.getQuoteOnce(tokenAddress, quoteMint, probeTokens);
        if (!quote) {
          quote = await this.waitForRoute(tokenAddress, quoteMint, probeTokens, waitMs, pollMs);
        }
        if (!quote) {
          return null;
        }

        const outLamports = Number(quote.outAmount ?? 0);
        if (!Number.isFinite(outLamports) || outLamports <= 0) {
          return null;
        }

        const outSOL = outLamports / 1e9;
        return outSOL / probeTokens;
      };

      return (await trySolToToken()) ?? (await tryTokenToSol());
    } catch (error) {
      this.logger.error('Error getting current price:', error);
      return null;
    }
  }

  public async start(): Promise<void> {
    if (this.isRunning) {
      this.logger.warn('Bot is already running');
      return;
    }

    try {
      this.logger.info('Starting trading bot...');

      // Primary connection via service
      await this.pumpPortal.connect();

      this.isRunning = true;
      this.startTime = Date.now();
      this.lastPumpEventTs = Date.now();

      // Start fallback watchdog
      this.startWatchdog();

      // Start monitoring loop
      this.startMonitoringLoop();
      this.startMomentumLoop();

      this.logger.info('Trading bot started successfully');
      await this.telegram.sendMessage('🤖 <b>Trading Bot Started</b>\nBot is now running and monitoring for new token launches.');

    } catch (error) {
      this.logger.error('Error starting trading bot:', error);
      throw error;
    }
  }

  public async stop(): Promise<void> {
    if (!this.isRunning) {
      this.logger.warn('Bot is not running');
      return;
    }

    try {
      this.logger.info('Stopping trading bot...');

      this.isRunning = false;
      this.stopMomentumLoop();
      this.pumpPortal.disconnect();

      if (this.ws) {
        try { this.ws.close(); } catch {}
        this.ws = null;
      }
      if (this.watchdogTimer) {
        clearInterval(this.watchdogTimer);
        this.watchdogTimer = null;
      }

      if (this.watchlist.size > 0) {
        for (const tokenAddress of Array.from(this.watchlist.keys())) {
          this.dropMomentumCandidate(tokenAddress, 'bot_stopped');
        }
        this.watchlist.clear();
      }

      for (const trade of this.activeTrades.values()) {
        await this.executeSell(trade, 'manual');
      }

      this.logger.info('Trading bot stopped successfully');
      await this.telegram.sendMessage('🛑 <b>Trading Bot Stopped</b>\nBot has been stopped and all positions closed.');

    } catch (error) {
      this.logger.error('Error stopping trading bot:', error);
      throw error;
    }
  }

  private startMonitoringLoop(): void {
    const monitorInterval = setInterval(async () => {
      if (!this.isRunning) {
        clearInterval(monitorInterval);
        return;
      }

      try {
        await this.monitorTrades();
      } catch (error) {
        this.logger.error('Error in monitoring loop:', error);
      }
    }, 5000); // Check every 5 seconds
  }

  private loadTrades(): void {
    try {
      if (fs.existsSync(this.tradesFile)) {
        const data = fs.readFileSync(this.tradesFile, 'utf8');
        const parsed = JSON.parse(data);
        const trades: Trade[] = Array.isArray(parsed)
          ? parsed.map((entry: Trade) => this.upgradeTradeRecord(entry))
          : [];

        this.activeTrades = new Map(
          trades
            .filter((trade: Trade) => trade.status === 'open')
            .map((trade: Trade) => [trade.tokenAddress, trade])
        );

        this.completedTrades = trades.filter((trade: Trade) => trade.status !== 'open');

        this.logger.info(`Loaded ${this.activeTrades.size} active trades and ${this.completedTrades.length} completed trades`);
      }
    } catch (error) {
      this.logger.error('Error loading trades:', error);
    } finally {
      this.updateMonitoringState();
    }
  }

  private saveTrades(): void {
    try {
      const allTrades = [
        ...Array.from(this.activeTrades.values()),
        ...this.completedTrades
      ];

      fs.writeFileSync(this.tradesFile, JSON.stringify(allTrades, null, 2));
    } catch (error) {
      this.logger.error('Error saving trades:', error);
    }
  }

  public getStatus(): BotStatus {
    const totalTrades = this.completedTrades.length + this.activeTrades.size;
    const totalPnL = this.completedTrades.reduce((sum, trade) => sum + (trade.pnl || 0), 0);
    const totalInvestment = this.completedTrades.reduce((sum, trade) => sum + trade.buyAmount, 0);
    const totalPnLPercentage = totalInvestment > 0 ? (totalPnL / totalInvestment) * 100 : 0;

    return {
      isRunning: this.isRunning,
      activeTrades: this.activeTrades.size,
      totalTrades,
      totalPnL,
      totalPnLPercentage,
      uptime: this.isRunning ? Date.now() - this.startTime : 0,
      lastTradeTime: this.completedTrades.length > 0
        ? Math.max(...this.completedTrades.map(t => t.sellTimestamp || t.buyTimestamp))
        : undefined
    };
  }

  public getActiveTrades(): Trade[] {
    return Array.from(this.activeTrades.values());
  }

  public getCompletedTrades(): Trade[] {
    return this.completedTrades;
  }

  public isBotRunning(): boolean {
    return this.isRunning;
  }
}




































