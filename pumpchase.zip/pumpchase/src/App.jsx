import { useState } from 'react'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <div className="App">
      <div className="hero">
        <h1>🚀 PumpChase</h1>
        <p className="subtitle">Track your crypto pumps and maximize gains</p>

        <div className="card">
          <button onClick={() => setCount((count) => count + 1)}>
            Count is {count}
          </button>
          <p>
            Edit <code>src/App.jsx</code> and save to test HMR
          </p>
        </div>

        <div className="features">
          <div className="feature">
            <h3>📈 Real-time Tracking</h3>
            <p>Monitor crypto pumps as they happen</p>
          </div>
          <div className="feature">
            <h3>🔔 Smart Alerts</h3>
            <p>Get notified for optimal entry points</p>
          </div>
          <div className="feature">
            <h3>📊 Analytics</h3>
            <p>Analyze pump patterns and performance</p>
          </div>
        </div>

        <p className="read-the-docs">
          Built with React + Vite
        </p>
      </div>
    </div>
  )
}

export default App